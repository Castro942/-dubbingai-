"""
Transcriber Module - Versao com suporte a FFmpeg
Transcribes audio to text using Whisper
"""

import os
import logging
import numpy as np

# Add FFmpeg to PATH (from app.py)
FFMPEG_PATH = r"C:\Users\Administrador\Desktop\ffmpeg-8.0.1-essentials_build\bin"
if FFMPEG_PATH not in os.environ.get('PATH', ''):
    os.environ['PATH'] = FFMPEG_PATH + os.pathsep + os.environ.get('PATH', '')

# Try to import whisper and torch, make them optional
try:
    import whisper
    import torch
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False
    print("WARNING: whisper not available. Transcription will use simulated results.")

logger = logging.getLogger(__name__)

# Global model cache
_model = None

def get_whisper_model(model_size="base"):
    """
    Get or load Whisper model
    
    Args:
        model_size: Size of model ('tiny', 'base', 'small', 'medium', 'large')
        
    Returns:
        Loaded Whisper model
    """
    global _model
    
    if _model is not None:
        return _model
    
    if not WHISPER_AVAILABLE:
        raise ImportError("Whisper is not available. Please install it with: pip install whisper")
    
    logger.info(f"Loading Whisper model: {model_size}")
    
    # Check device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    logger.info(f"Using device: {device}")
    
    # Load model
    _model = whisper.load_model(model_size, device=device)
    
    logger.info("Whisper model loaded successfully")
    return _model

def transcribe_audio(audio_path, source_lang="auto"):
    """
    Transcribe audio to text using Whisper
    
    Args:
        audio_path: Path to audio file
        source_lang: Source language ('auto' for automatic detection)
        
    Returns:
        Transcribed text with timestamps
    """
    if not WHISPER_AVAILABLE:
        logger.warning("Whisper not available, returning simulated transcription")
        return "Transcricao simulada. O Whisper nao esta instalado."
    
    try:
        logger.info(f"Transcribing audio: {audio_path}")
        
        # Load model
        model = get_whisper_model("base")
        
        # Prepare options
        options = {
            "fp16": False,
            "verbose": True,
        }
        
        if source_lang != "auto":
            options["language"] = source_lang
        
        # Transcribe
        result = model.transcribe(audio_path, **options)
        
        # Extract text and segments
        text = result["text"]
        segments = result.get("segments", [])
        
        logger.info(f"Transcription completed: {len(text)} characters")
        
        # Return formatted text
        return text
        
    except Exception as e:
        logger.error(f"Transcription error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Fallback: return simulated transcription
        return "Falha na transcricao. Por favor, tente novamente."

def transcribe_with_timestamps(audio_path, source_lang="auto"):
    """
    Transcribe audio with precise timestamps
    
    Args:
        audio_path: Path to audio file
        source_lang: Source language
        
    Returns:
        List of segments with start, end, and text
    """
    if not WHISPER_AVAILABLE:
        logger.warning("Whisper not available, returning simulated segments")
        return [
            {"start": 0.0, "end": 5.0, "text": "Segmento de transcricao simulado", "language": "pt"}
        ]
    
    try:
        logger.info(f"Transcribing with timestamps: {audio_path}")
        
        model = get_whisper_model("base")
        
        options = {
            "fp16": False,
            "verbose": False,
        }
        
        if source_lang != "auto":
            options["language"] = source_lang
        
        result = model.transcribe(audio_path, **options)
        
        segments = result.get("segments", [])
        
        formatted_segments = []
        for seg in segments:
            formatted_segments.append({
                "start": seg.get("start", 0),
                "end": seg.get("end", 0),
                "text": seg.get("text", "").strip(),
                "language": result.get("language", "unknown")
            })
        
        return formatted_segments
        
    except Exception as e:
        logger.error(f"Timestamp transcription error: {str(e)}")
        return []

def get_audio_language(audio_path):
    """
    Detect language of audio
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Detected language code
    """
    try:
        model = get_whisper_model("base")
        
        # Load audio
        import whisper
        audio = whisper.load_audio(audio_path)
        audio = whisper.pad_or_trim(audio)
        
        # Create mel spectrogram
        mel = whisper.log_mel_spectrogram(audio, n_mels=model.dims.n_mels).to(model.device)
        
        # Detect language
        _, probs = model.detect_language(mel)
        detected_lang = max(probs, key=probs.get)
        
        logger.info(f"Detected language: {detected_lang}")
        
        return detected_lang
        
    except Exception as e:
        logger.error(f"Language detection error: {str(e)}")
        return "en"  # Default to English
