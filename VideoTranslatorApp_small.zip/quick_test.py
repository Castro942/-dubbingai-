# -*- coding: utf-8 -*-
"""Quick test of AI features"""
import sys
sys.path.insert(0, '.')

print("=" * 50)
print("DUBBINGAI PRO - TESTE RÁPIDO")
print("=" * 50)

# Test 1: Emotion analyzer
print("\n[1] Emotion Analyzer...")
try:
    from processors.emotion_analyzer import EMOTION_CATEGORIES, analyze_emotions
    print(f"   OK - {len(EMOTION_CATEGORIES)} emoções disponíveis")
    print(f"   Emoções: {', '.join(EMOTION_CATEGORIES.keys())}")
except Exception as e:
    print(f"   ERRO: {e}")

# Test 2: PT-BR dubbing styles
print("\n[2] Estilos de Dublagem PT-BR...")
try:
    from processors.ptbr_dubbing_style import get_all_presets, get_presets_by_category
    presets = get_all_presets()
    print(f"   OK - {len(presets)} presets disponíveis")
    print("   Principais:")
    for k in list(presets.keys())[:5]:
        print(f"      - {k}")
except Exception as e:
    print(f"   ERRO: {e}")

# Test 3: Voice cloner
print("\n[3] Clonagem de Voz...")
try:
    from processors.voice_cloner import extract_voice_characteristics
    print("   OK - Módulo carregado")
except Exception as e:
    print(f"   ERRO: {e}")

# Test 4: Professional TTS
print("\n[4] TTS Profissional...")
try:
    from processors.pro_tts_generator import get_tts_engine
    print("   OK - Módulo carregado")
except Exception as e:
    print(f"   ERRO: {e}")

# Test 5: Flask app
print("\n[5] Servidor Flask...")
try:
    from app import app
    print(f"   OK - {len(app.url_map._rules)} rotas configuradas")
except Exception as e:
    print(f"   ERRO: {e}")

print("\n" + "=" * 50)
print("TESTE CONCLUÍDO!")
print("=" * 50)
print("\nPara iniciar o app, execute o arquivo:")
print("  DubbingAI/iniciar_app.bat")
print("\nE abra no navegador: http://localhost:5000")
