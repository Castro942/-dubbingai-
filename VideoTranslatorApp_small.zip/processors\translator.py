"""
Translator Module
Translates text to Portuguese using free translation APIs
"""

import logging
from deep_translator import GoogleTranslator

logger = logging.getLogger(__name__)

def translate_text(text, target_lang="pt", source_lang="auto"):
    """
    Translate text to target language
    
    Args:
        text: Text to translate
        target_lang: Target language code (default: Portuguese)
        source_lang: Source language (auto for automatic detection)
        
    Returns:
        Translated text
    """
    try:
        if not text or len(text.strip()) == 0:
            return ""
        
        logger.info(f"Translating text to {target_lang}...")
        
        # Initialize translator
        translator = GoogleTranslator(source=source_lang, target=target_lang)
        
        # Translate
        result = translator.translate(text)
        
        logger.info(f"Translation completed: {len(result)} characters")
        
        return result
        
    except Exception as e:
        logger.error(f"Translation error: {str(e)}")
        
        # Try alternative approach
        try:
            # Split into chunks if text is too long
            chunks = []
            max_chunk_size = 4500
            
            for i in range(0, len(text), max_chunk_size):
                chunks.append(text[i:i + max_chunk_size])
            
            translated_chunks = []
            for chunk in chunks:
                translator = GoogleTranslator(source="auto", target=target_lang)
                translated_chunks.append(translator.translate(chunk))
            
            return " ".join(translated_chunks)
            
        except Exception as e2:
            logger.error(f"Alternative translation also failed: {str(e2)}")
            return f"[Translation failed] {text}"

def translate_segments(segments, target_lang="pt"):
    """
    Translate timestamped segments
    
    Args:
        segments: List of segments with 'text' key
        target_lang: Target language
        
    Returns:
        List of translated segments
    """
    try:
        translated_segments = []
        
        for segment in segments:
            text = segment.get("text", "")
            
            if text:
                translated_text = translate_text(text, target_lang)
                segment["translated"] = translated_text
            else:
                segment["translated"] = ""
            
            translated_segments.append(segment)
        
        return translated_segments
        
    except Exception as e:
        logger.error(f"Segment translation error: {str(e)}")
        return segments

def translate_with_timestamps(transcription_result, target_lang="pt"):
    """
    Translate transcription result with timestamps
    
    Args:
        transcription_result: Dict with 'text' and 'segments'
        target_lang: Target language
        
    Returns:
        Translated result with timestamps
    """
    try:
        # Translate main text
        translated_text = translate_text(
            transcription_result.get("text", ""), 
            target_lang
        )
        
        # Translate each segment
        translated_segments = translate_segments(
            transcription_result.get("segments", []),
            target_lang
        )
        
        return {
            "original_text": transcription_result.get("text", ""),
            "translated_text": translated_text,
            "segments": translated_segments,
            "source_lang": transcription_result.get("language", "unknown"),
            "target_lang": target_lang
        }
        
    except Exception as e:
        logger.error(f"Timestamped translation error: {str(e)}")
        return {
            "original_text": "",
            "translated_text": "Translation failed",
            "segments": [],
            "source_lang": "unknown",
            "target_lang": target_lang
        }

def detect_language(text):
    """
    Simple language detection
    
    Args:
        text: Text to analyze
        
    Returns:
        Language code
    """
    try:
        # Use Google Translator's detection
        translator = GoogleTranslator(source="auto", target="en")
        
        # Try translating a sample
        sample = text[:100] if len(text) > 100 else text
        
        # Use langdetect as fallback
        try:
            from langdetect import detect
            return detect(sample)
        except:
            pass
        
        # Default
        return "en"
        
    except Exception as e:
        logger.error(f"Language detection error: {str(e)}")
        return "en"
