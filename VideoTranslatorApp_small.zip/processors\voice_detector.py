"""
Voice Gender Detector Module
Detects male and female voices in audio using acoustic analysis
"""

import os
import logging
import numpy as np
from pydub import AudioSegment
import math

# Try to import librosa, make it optional
try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False
    print("WARNING: librosa not available. Voice gender detection will use default values.")

logger = logging.getLogger(__name__)

# Gender classification thresholds (based on fundamental frequency)
MALE_F0_MIN = 85   # Hz
MALE_F0_MAX = 180  # Hz
FEMALE_F0_MIN = 165  # Hz
FEMALE_F0_MAX = 255  # Hz

def extract_pitch_features(audio_path, segment_duration=3.0):
    """
    Extract pitch (F0) features from audio
    
    Args:
        audio_path: Path to audio file
        segment_duration: Duration of each segment to analyze
        
    Returns:
        List of dictionaries with pitch data
    """
    if not LIBROSA_AVAILABLE:
        logger.warning("librosa not available, returning empty pitch data")
        return []
        
    try:
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050)
        
        # Get duration
        duration = len(y) / sr
        
        # Analyze in segments
        hop_length = 512
        frame_length = 2048
        
        segments_data = []
        segment_samples = int(segment_duration * sr)
        num_segments = int(duration / segment_duration)
        
        for i in range(num_segments):
            start_sample = i * segment_samples
            end_sample = min((i + 1) * segment_samples, len(y))
            
            if end_sample - start_sample < segment_samples * 0.5:
                continue
            
            y_segment = y[start_sample:end_sample]
            
            # Extract pitch using yin algorithm
            try:
                f0, voiced_flag, voiced_probs = librosa.pyin(
                    y_segment,
                    fmin=50,
                    fmax=500,
                    sr=sr,
                    hop_length=hop_length
                )
                
                # Get median F0 (ignoring NaN values)
                f0_valid = f0[~np.isnan(f0)]
                
                if len(f0_valid) > 0:
                    median_f0 = np.median(f0_valid)
                    mean_f0 = np.mean(f0_valid)
                    
                    segments_data.append({
                        'start_time': i * segment_duration,
                        'end_time': (i + 1) * segment_duration,
                        'median_f0': float(median_f0),
                        'mean_f0': float(mean_f0),
                        'voiced_ratio': len(f0_valid) / len(f0) if len(f0) > 0 else 0
                    })
            except Exception as e:
                logger.warning(f"Pitch extraction failed for segment {i}: {str(e)}")
                continue
        
        return segments_data
        
    except Exception as e:
        logger.error(f"Error extracting pitch features: {str(e)}")
        return []

def classify_gender_by_pitch(f0):
    """
    Classify voice gender based on fundamental frequency
    
    Args:
        f0: Fundamental frequency in Hz
        
    Returns:
        'male', 'female', or 'unknown'
    """
    if f0 is None or np.isnan(f0):
        return 'unknown'
    
    if MALE_F0_MIN <= f0 <= MALE_F0_MAX:
        return 'male'
    elif FEMALE_F0_MIN <= f0 <= FEMALE_F0_MAX:
        return 'female'
    elif f0 < MALE_F0_MIN:
        return 'male'  # Very low pitch = likely male
    elif f0 > FEMALE_F0_MAX:
        return 'female'  # Very high pitch = likely female
    else:
        # In between - use thresholds
        mid_male = (MALE_F0_MAX + FEMALE_F0_MIN) / 2
        if f0 < mid_male:
            return 'male'
        else:
            return 'female'

def detect_voice_genders(audio_path):
    """
    Detect voice genders throughout the audio file
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        List of dictionaries with time segments and gender info
    """
    try:
        logger.info(f"Detecting voice genders in: {audio_path}")
        
        # Extract pitch features
        pitch_data = extract_pitch_features(audio_path, segment_duration=3.0)
        
        if not pitch_data:
            logger.warning("No pitch data extracted, using default segmentation")
            # Create default segments based on audio duration
            from processors.audio_processor import get_audio_duration
            duration = get_audio_duration(audio_path)
            num_segments = int(duration / 5.0)
            
            return [
                {
                    'start_time': i * 5.0,
                    'end_time': min((i + 1) * 5.0, duration),
                    'gender': 'female',  # Default to female for dubbing
                    'f0': 200.0,
                    'confidence': 0.5
                }
                for i in range(num_segments)
            ]
        
        # Classify each segment by gender
        voice_segments = []
        
        for segment in pitch_data:
            f0 = segment['median_f0']
            gender = classify_gender_by_pitch(f0)
            
            # Calculate confidence based on how far from threshold
            if gender == 'male':
                confidence = min(1.0, (MALE_F0_MAX - f0) / 50 + 0.5)
            elif gender == 'female':
                confidence = min(1.0, (f0 - FEMALE_F0_MIN) / 50 + 0.5)
            else:
                confidence = 0.5
            
            voice_segments.append({
                'start_time': segment['start_time'],
                'end_time': segment['end_time'],
                'gender': gender,
                'f0': f0,
                'confidence': float(confidence)
            })
        
        # Merge consecutive segments with same gender
        merged_segments = merge_consecutive_segments(voice_segments)
        
        logger.info(f"Detected {len(merged_segments)} voice segments")
        
        return merged_segments
        
    except Exception as e:
        logger.error(f"Error detecting voice genders: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Return default segments
        return [
            {
                'start_time': 0.0,
                'end_time': 10.0,
                'gender': 'female',
                'f0': 200.0,
                'confidence': 0.5
            }
        ]

def merge_consecutive_segments(segments):
    """
    Merge consecutive segments with the same gender
    
    Args:
        segments: List of voice segment dictionaries
        
    Returns:
        Merged segments list
    """
    if not segments:
        return []
    
    merged = [segments[0].copy()]
    
    for segment in segments[1:]:
        last = merged[-1]
        
        # If same gender and close in time, merge
        if (segment['gender'] == last['gender'] and 
            segment['start_time'] - last['end_time'] < 1.0):
            last['end_time'] = segment['end_time']
            # Average F0
            last['f0'] = (last['f0'] + segment['f0']) / 2
            # Higher confidence
            last['confidence'] = min(1.0, last['confidence'] + 0.1)
        else:
            merged.append(segment.copy())
    
    return merged

def get_dominant_gender(voice_segments):
    """
    Get the dominant gender in the audio
    
    Args:
        voice_segments: List of voice segment dictionaries
        
    Returns:
        'male', 'female', or 'mixed'
    """
    if not voice_segments:
        return 'female'  # Default
    
    male_time = sum(
        s['end_time'] - s['start_time'] 
        for s in voice_segments 
        if s['gender'] == 'male'
    )
    female_time = sum(
        s['end_time'] - s['start_time'] 
        for s in voice_segments 
        if s['gender'] == 'female'
    )
    
    total_time = male_time + female_time
    
    if total_time == 0:
        return 'female'
    
    male_ratio = male_time / total_time
    
    if male_ratio > 0.7:
        return 'male'
    elif male_ratio < 0.3:
        return 'female'
    else:
        return 'mixed'
