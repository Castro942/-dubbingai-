"""
Professional Brazilian Portuguese Dubbing App
Advanced video translation with emotion preservation, voice cloning,
and professional Brazilian Portuguese dubbing quality
"""

import os
import sys
import uuid
import tempfile
import shutil
import json

# Add FFmpeg to PATH
FFMPEG_PATH = r"C:\Users\Administrador\Desktop\ffmpeg-8.0.1-essentials_build\bin"
if FFMPEG_PATH not in os.environ.get('PATH', ''):
    os.environ['PATH'] = FFMPEG_PATH + os.pathsep + os.environ.get('PATH', '')

from flask import Flask, render_template, request, jsonify, send_file, after_this_request
from flask_cors import CORS
from werkzeug.utils import secure_filename
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
app.config['OUTPUT_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'output')
app.config['VOICE_PROFILES_DIR'] = os.path.join(os.path.dirname(__file__), 'static', 'voice_profiles')

# Create directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)
os.makedirs(app.config['VOICE_PROFILES_DIR'], exist_ok=True)

# Allowed extensions
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mkv', 'mov', 'webm', 'mp3', 'wav', 'flac'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Render main page"""
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_video():
    """Handle video/audio upload"""
    try:
        if 'video' not in request.files and 'audio' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files.get('video') or request.files.get('audio')
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Allowed: mp4, avi, mkv, mov, webm, mp3, wav, flac'}), 400
        
        # Generate unique ID for this session
        session_id = str(uuid.uuid4())
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{session_id}_{filename}")
        file.save(filepath)
        
        logger.info(f"File uploaded: {filepath}")
        
        # Determine file type
        file_type = 'video' if filename.rsplit('.', 1)[1].lower() in {'mp4', 'avi', 'mkv', 'mov', 'webm'} else 'audio'
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'filename': filename,
            'filepath': f"/static/uploads/{session_id}_{filename}",
            'file_type': file_type
        })
        
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyze', methods=['POST'])
def analyze_audio():
    """Analyze audio for voice characteristics, emotion, and gender"""
    try:
        data = request.json
        session_id = data.get('session_id')
        
        if not session_id:
            return jsonify({'error': 'No session ID provided'}), 400
        
        # Find the uploaded file
        upload_dir = app.config['UPLOAD_FOLDER']
        session_files = [f for f in os.listdir(upload_dir) if f.startswith(session_id)]
        
        if not session_files:
            return jsonify({'error': 'File not found. Please upload again'}), 404
        
        file_path = os.path.join(upload_dir, session_files[0])
        
        # Import new processors
        from processors.emotion_analyzer import analyze_emotions
        from processors.voice_cloner import extract_voice_characteristics, save_voice_profile
        from processors.voice_detector import detect_voice_genders
        
        output_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
        os.makedirs(output_dir, exist_ok=True)
        
        # Step 1: Extract audio if video
        audio_path = file_path
        if file_path.endswith(('.mp4', '.avi', '.mkv', '.mov', '.webm')):
            from processors.audio_processor import extract_audio
            audio_path = extract_audio(file_path, output_dir)
        
        # Step 2: Analyze emotions
        logger.info("Step 1: Analyzing emotions...")
        emotion_analysis = analyze_emotions(audio_path)
        
        # Step 3: Extract voice characteristics
        logger.info("Step 2: Extracting voice characteristics...")
        voice_profile = extract_voice_characteristics(audio_path)
        
        # Save voice profile
        profile_path = save_voice_profile(voice_profile, session_id)
        
        # Step 4: Detect voice genders
        logger.info("Step 3: Detecting voice genders...")
        voice_segments = detect_voice_genders(audio_path)
        
        # Get voice preset suggestion
        from processors.ptbr_dubbing_style import suggest_voice_from_emotion, get_voice_preset_for_content
        
        gender = voice_profile.gender if voice_profile else 'male'
        emotion = emotion_analysis.get('primary_emotion', 'neutral') if emotion_analysis else 'neutral'
        
        suggested_preset = suggest_voice_from_emotion(emotion, gender)
        
        return jsonify({
            'success': True,
            'analysis': {
                'emotion': {
                    'primary': emotion_analysis.get('primary_emotion', 'neutral'),
                    'confidence': emotion_analysis.get('confidence', 0.5),
                    'emotion_params': emotion_analysis.get('emotion_params', {}),
                    'speaking_rate': emotion_analysis.get('speaking_rate', {})
                },
                'voice': {
                    'gender': voice_profile.gender if voice_profile else 'unknown',
                    'age_group': voice_profile.age_group if voice_profile else 'adult',
                    'mean_pitch': voice_profile.mean_pitch if voice_profile else 0,
                    'confidence': voice_profile.confidence if voice_profile else 0
                },
                'voice_segments': voice_segments[:10],
                'suggested_preset': suggested_preset,
                'profile_saved': profile_path is not None
            }
        })
        
    except Exception as e:
        logger.error(f"Analysis error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/process', methods=['POST'])
def process_video():
    """Process video with professional dubbing"""
    try:
        data = request.json
        session_id = data.get('session_id')
        source_lang = data.get('source_lang', 'auto')
        
        # New options
        voice_preset = data.get('voice_preset', 'auto')
        emotion_preservation = data.get('emotion_preservation', True)
        voice_cloning = data.get('voice_cloning', True)
        content_type = data.get('content_type', 'movie')  # anime, cartoon, movie, documentary
        
        if not session_id:
            return jsonify({'error': 'No session ID provided'}), 400
        
        # Find the uploaded file
        upload_dir = app.config['UPLOAD_FOLDER']
        session_files = [f for f in os.listdir(upload_dir) if f.startswith(session_id)]
        
        if not session_files:
            return jsonify({'error': 'File not found. Please upload again'}), 404
        
        video_path = os.path.join(upload_dir, session_files[0])
        
        # Import processors
        from processors.audio_processor import extract_audio
        from processors.voice_detector import detect_voice_genders
        from processors.transcriber import transcribe_audio, transcribe_with_timestamps
        from processors.translator import translate_text, translate_segments
        from processors.video_merger import merge_audio_video
        
        output_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
        os.makedirs(output_dir, exist_ok=True)
        
        # Step 1: Extract audio
        logger.info("Step 1: Extracting audio from video...")
        audio_path = extract_audio(video_path, output_dir)
        
        # Step 2: Analyze emotions (new)
        from processors.emotion_analyzer import analyze_emotions
        logger.info("Step 2: Analyzing emotions...")
        emotion_analysis = analyze_emotions(audio_path)
        
        # Step 3: Detect voice characteristics
        logger.info("Step 3: Detecting voice characteristics...")
        voice_segments = detect_voice_genders(audio_path)
        
        # Extract voice profile
        from processors.voice_cloner import extract_voice_characteristics, load_voice_profile
        voice_profile = extract_voice_characteristics(audio_path)
        
        # Step 4: Transcribe audio with timestamps
        logger.info("Step 4: Transcribing audio...")
        transcription = transcribe_audio(audio_path, source_lang)
        transcription_segments = transcribe_with_timestamps(audio_path, source_lang)
        
        # Step 5: Translate to Portuguese with timestamps
        logger.info("Step 5: Translating to Portuguese...")
        translated = translate_text(transcription)
        translated_segments = translate_segments(transcription_segments)
        
        # Step 6: Generate dubbed audio using professional TTS
        logger.info("Step 6: Generating professional dubbed audio...")
        
        # Get voice preset
        from processors.ptbr_dubbing_style import get_voice_preset_for_content, suggest_voice_from_emotion
        
        gender = voice_profile.gender if voice_profile else 'male'
        emotion = emotion_analysis.get('primary_emotion', 'neutral') if emotion_analysis else 'neutral'
        
        if voice_preset == 'auto':
            voice_preset = suggest_voice_from_emotion(emotion, gender)
        
        # Use professional TTS generator
        from processors.pro_tts_generator import generate_professional_speech, generate_segmented_dubbed_audio
        
        # Generate audio
        dubbed_audio_path = generate_professional_speech(
            text=translated,
            voice_preset=voice_preset,
            emotion_data=emotion_analysis if emotion_preservation else None,
            voice_profile=voice_profile if voice_cloning else None,
            output_dir=output_dir,
            session_id=session_id
        )
        
        # If we have segmented translations, use them for better timing
        if transcription_segments and len(translated_segments) > 1:
            dubbed_audio_path = generate_segmented_dubbed_audio(
                translated_segments=translated_segments,
                voice_segments=voice_segments,
                emotion_analysis=emotion_analysis if emotion_preservation else None,
                voice_profiles=[voice_profile] if voice_cloning else None,
                output_dir=output_dir
            )
        
        # Step 7: Merge with video
        logger.info("Step 7: Merging audio with video...")
        
        video_filename = f"dubbed_{os.path.splitext(os.path.basename(video_path))[0]}.mp4"
        final_video_path = os.path.join(output_dir, video_filename)
        
        final_video_path = merge_audio_video(
            video_path, 
            dubbed_audio_path, 
            final_video_path
        )
        
        # Return results
        video_filename = os.path.basename(final_video_path)
        
        return jsonify({
            'success': True,
            'message': 'Professional dubbing completed!',
            'result': {
                'video_url': f"/static/output/{session_id}/{video_filename}",
                'transcription': transcription[:500] + '...' if len(transcription) > 500 else transcription,
                'translation': translated[:500] + '...' if len(translated) > 500 else translated,
                'voice_segments': voice_segments[:10],
                'emotion': {
                    'primary': emotion_analysis.get('primary_emotion', 'neutral'),
                    'confidence': emotion_analysis.get('confidence', 0.5)
                },
                'voice_profile': {
                    'gender': voice_profile.gender if voice_profile else 'unknown',
                    'pitch': voice_profile.mean_pitch if voice_profile else 0
                },
                'settings': {
                    'voice_preset': voice_preset,
                    'emotion_preservation': emotion_preservation,
                    'voice_cloning': voice_cloning,
                    'content_type': content_type
                }
            }
        })
        
    except Exception as e:
        logger.error(f"Processing error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/presets', methods=['GET'])
def get_voice_presets():
    """Get available voice presets"""
    try:
        from processors.ptbr_dubbing_style import get_all_presets, get_presets_by_category
        
        return jsonify({
            'success': True,
            'presets': get_all_presets(),
            'categories': get_presets_by_category()
        })
        
    except Exception as e:
        logger.error(f"Presets error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/voice-profiles/<session_id>', methods=['GET'])
def get_voice_profile(session_id):
    """Get saved voice profile for session"""
    try:
        from processors.voice_cloner import load_voice_profile
        
        profile = load_voice_profile(session_id)
        
        if profile:
            return jsonify({
                'success': True,
                'profile': profile.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Profile not found'
            }), 404
            
    except Exception as e:
        logger.error(f"Profile error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/emotions', methods=['GET'])
def get_emotions():
    """Get available emotion settings"""
    try:
        from processors.emotion_analyzer import EMOTION_CATEGORIES
        
        return jsonify({
            'success': True,
            'emotions': EMOTION_CATEGORIES
        })
        
    except Exception as e:
        logger.error(f"Emotions error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/status/<session_id>', methods=['GET'])
def get_status(session_id):
    """Check processing status"""
    return jsonify({'status': 'processing', 'message': 'Video is being processed'})

@app.route('/api/download/<filename>', methods=['GET'])
def download_file(filename):
    """Download processed video"""
    try:
        return send_file(
            os.path.join(app.config['OUTPUT_FOLDER'], filename),
            as_attachment=True,
            download_name=f"dubbed_{filename}"
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 404

@app.route('/api/cleanup', methods=['POST'])
def cleanup():
    """Clean up old session files"""
    try:
        import time
        current_time = time.time()
        max_age = 24 * 60 * 60  # 24 hours
        
        for folder in [app.config['UPLOAD_FOLDER'], app.config['OUTPUT_FOLDER']]:
            if os.path.exists(folder):
                for item in os.listdir(folder):
                    item_path = os.path.join(folder, item)
                    if os.path.getmtime(item_path) < current_time - max_age:
                        if os.path.isfile(item_path):
                            os.remove(item_path)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
        
        return jsonify({'success': True, 'message': 'Cleanup completed'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
