# -*- coding: utf-8 -*-
"""Minimal Flask server test"""
from flask import Flask, render_template_string

app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>DubbingAI Test</title>
    <style>
        body { font-family: Arial; background: #1a1a2e; color: white; padding: 50px; text-align: center; }
        h1 { color: #e94560; }
    </style>
</head>
<body>
    <h1>DubbingAI Pro - Test Server</h1>
    <p>Server is running!</p>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML)

if __name__ == '__main__':
    print("Starting test server on http://localhost:5002")
    app.run(host='0.0.0.0', port=5002, debug=False)
