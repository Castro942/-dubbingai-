// DubbingAI Pro - Frontend Logic

const App = {
    sessionId: null,
    videoPath: null,
    fileType: 'video',
    analysisData: null,
    
    // Initialize app
    init() {
        this.setupEventListeners();
        this.loadPresets();
    },
    
    // Setup event listeners
    setupEventListeners() {
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const processBtn = document.getElementById('processBtn');
        const newVideoBtn = document.getElementById('newVideoBtn');
        
        // Click to upload
        dropZone.addEventListener('click', () => fileInput.click());
        
        // File input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFileUpload(e.target.files[0]);
            }
        });
        
        // Drag and drop
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });
        
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('drag-over');
        });
        
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            if (e.dataTransfer.files.length > 0) {
                this.handleFileUpload(e.dataTransfer.files[0]);
            }
        });
        
        // Process button
        if (processBtn) {
            processBtn.addEventListener('click', () => this.processVideo());
        }
        
        // New video button
        if (newVideoBtn) {
            newVideoBtn.addEventListener('click', () => this.resetApp());
        }
        
        // Tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tabId = btn.dataset.tab;
                this.switchTab(tabId);
            });
        });
        
        // Content type change
        document.getElementById('contentType').addEventListener('change', (e) => {
            this.updateVoicePresetSuggestions(e.target.value);
        });
    },
    
    // Load voice presets
    async loadPresets() {
        try {
            const response = await fetch('/api/presets');
            const data = await response.json();
            
            if (data.success) {
                this.presets = data.presets;
                this.presetCategories = data.categories;
            }
        } catch (error) {
            console.error('Error loading presets:', error);
        }
    },
    
    // Update voice preset suggestions based on content type
    updateVoicePresetSuggestions(contentType) {
        const voiceSelect = document.getElementById('voicePreset');
        
        // Auto-select recommended preset
        if (voiceSelect.value === 'auto') {
            const suggestions = {
                'anime': 'dubbing_anime_male',
                'cartoon': 'dubbing_cartoon',
                'movie': 'dubbing_movie_drama',
                'documentary': 'dubbing_documentary',
                'comedy': 'dubbing_comedy'
            };
            
            if (suggestions[contentType]) {
                voiceSelect.value = suggestions[contentType];
            }
        }
    },
    
    // Handle file upload
    async handleFileUpload(file) {
        // Validate file
        const validExtensions = ['mp4', 'avi', 'mkv', 'mov', 'webm', 'mp3', 'wav', 'flac'];
        const extension = file.name.split('.').pop().toLowerCase();
        
        if (!validExtensions.includes(extension)) {
            alert('Tipo de arquivo inválido. Use: MP4, AVI, MKV, MOV, WEBM, MP3, WAV ou FLAC');
            return;
        }
        
        if (file.size > 500 * 1024 * 1024) {
            alert('Arquivo muito grande. Máximo: 500MB');
            return;
        }
        
        // Determine file type
        const videoExtensions = ['mp4', 'avi', 'mkv', 'mov', 'webm'];
        this.fileType = videoExtensions.includes(extension) ? 'video' : 'audio';
        
        // Show processing section
        document.getElementById('uploadSection').classList.add('hidden');
        document.getElementById('processingSection').classList.add('visible');
        
        // Update step
        this.updateStep('stepUpload', 'active');
        this.updateProgress(5, 'Enviando arquivo...');
        
        try {
            // Upload file
            const formData = new FormData();
            const fieldName = this.fileType === 'video' ? 'video' : 'audio';
            formData.append(fieldName, file);
            
            const uploadResponse = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            
            const uploadData = await uploadResponse.json();
            
            if (!uploadData.success) {
                throw new Error(uploadData.error || 'Erro ao enviar arquivo');
            }
            
            this.sessionId = uploadData.session_id;
            this.videoPath = uploadData.filepath;
            
            // Complete upload step
            this.updateStep('stepUpload', 'completed');
            this.updateProgress(15, 'Arquivo enviado!');
            
            // Start analysis
            await this.analyzeAudio();
            
        } catch (error) {
            console.error('Upload error:', error);
            alert('Erro ao enviar arquivo: ' + error.message);
            this.resetApp();
        }
    },
    
    // Analyze audio
    async analyzeAudio() {
        try {
            this.updateStep('stepAnalyze', 'active');
            this.updateProgress(25, 'Analisando áudio...');
            
            const analyzeResponse = await fetch('/api/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    session_id: this.sessionId
                })
            });
            
            const analyzeData = await analyzeResponse.json();
            
            if (!analyzeData.success) {
                throw new Error(analyzeData.error || 'Erro ao analisar áudio');
            }
            
            this.analysisData = analyzeData.analysis;
            
            // Update UI with analysis results
            this.displayAnalysisResults(analyzeData.analysis);
            
            this.updateStep('stepAnalyze', 'completed');
            this.updateProgress(40, 'Análise concluída!');
            
            // Show process button
            document.getElementById('processBtn').style.display = 'flex';
            
            // Switch back to upload section
            document.getElementById('processingSection').classList.remove('visible');
            document.getElementById('uploadSection').classList.remove('hidden');
            
        } catch (error) {
            console.error('Analysis error:', error);
            alert('Erro ao analisar áudio: ' + error.message);
            this.resetApp();
        }
    },
    
    // Display analysis results
    displayAnalysisResults(analysis) {
        const resultsSection = document.getElementById('analysisResults');
        resultsSection.classList.add('visible');
        
        // Update emotion
        const emotion = analysis.emotion.primary;
        const confidence = Math.round(analysis.emotion.confidence * 100);
        
        const emotionBadge = document.getElementById('emotionBadge');
        emotionBadge.textContent = this.capitalizeFirst(emotion);
        emotionBadge.className = 'emotion-badge ' + emotion;
        
        document.getElementById('emotionConfidence').textContent = `Confiança: ${confidence}%`;
        
        // Update gender
        const gender = analysis.voice.gender;
        const genderBadge = document.getElementById('genderBadge');
        genderBadge.textContent = gender === 'male' ? 'Masculino' : 'Feminino';
        genderBadge.className = 'gender-badge ' + gender;
        
        document.getElementById('pitchValue').textContent = `Pitch: ${Math.round(analysis.voice.mean_pitch)} Hz`;
        
        // Update recommended preset
        document.getElementById('recommendedPreset').textContent = `Voz: ${analysis.suggested_preset}`;
    },
    
    // Process video
    async processVideo() {
        // Get settings
        const contentType = document.getElementById('contentType').value;
        const voicePreset = document.getElementById('voicePreset').value;
        const emotionPreservation = document.getElementById('emotionToggle').checked;
        const voiceCloning = document.getElementById('voiceCloneToggle').checked;
        
        // Show processing section
        document.getElementById('uploadSection').classList.add('hidden');
        document.getElementById('processingSection').classList.add('visible');
        
        // Reset steps
        this.updateStep('stepTranscribe', 'active');
        this.updateProgress(50, 'Transcrevendo áudio...');
        
        try {
            // Call processing API
            const processResponse = await fetch('/api/process', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    session_id: this.sessionId,
                    source_lang: 'auto',
                    voice_preset: voicePreset,
                    emotion_preservation: emotionPreservation,
                    voice_cloning: voiceCloning,
                    content_type: contentType
                })
            });
            
            const processData = await processResponse.json();
            
            if (!processData.success) {
                throw new Error(processData.error || 'Erro ao processar vídeo');
            }
            
            // Update progress
            this.updateStep('stepTranscribe', 'completed');
            this.updateStep('stepTranslate', 'completed');
            this.updateStep('stepDub', 'completed');
            this.updateStep('stepMerge', 'completed');
            this.updateProgress(100, 'Processamento concluído!');
            
            // Show results
            await this.delay(500);
            this.showResults(processData.result);
            
        } catch (error) {
            console.error('Processing error:', error);
            alert('Erro ao processar: ' + error.message);
            this.resetApp();
        }
    },
    
    // Show results
    showResults(result) {
        document.getElementById('processingSection').classList.remove('visible');
        document.getElementById('resultSection').classList.add('visible');
        
        // Set video source
        const video = document.getElementById('resultVideo');
        video.src = result.video_url;
        
        // Set transcription
        document.getElementById('transcription').textContent = result.transcription || 'Transcrição não disponível';
        
        // Set translation
        document.getElementById('translation').textContent = result.translation || 'Tradução não disponível';
        
        // Set settings info
        const settingsText = `
Emoção Detectada: ${result.emotion.primary} (${Math.round(result.emotion.confidence * 100)}%)
Gênero da Voz: ${result.voice_profile.gender}
Pitch: ${Math.round(result.voice_profile.pitch)} Hz
Voz Selecionada: ${result.settings.voice_preset}
Preservar Emoção: ${result.settings.emotion_preservation ? 'Sim' : 'Não'}
Clonagem de Voz: ${result.settings.voice_cloning ? 'Sim' : 'Não'}
Tipo de Conteúdo: ${result.settings.content_type}
        `;
        document.getElementById('settings').textContent = settingsText;
        
        // Set download button
        const downloadBtn = document.getElementById('downloadBtn');
        downloadBtn.href = result.video_url;
        downloadBtn.download = 'video_dublado.mp4';
    },
    
    // Switch tab
    switchTab(tabId) {
        // Update buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });
        
        // Update content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabId);
        });
    },
    
    // Update progress step
    updateStep(stepId, status) {
        const step = document.getElementById(stepId);
        if (!step) return;
        
        step.classList.remove('active', 'completed');
        if (status) {
            step.classList.add(status);
        }
    },
    
    // Update progress bar
    updateProgress(percent, text) {
        const fill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        if (fill) {
            fill.style.width = percent + '%';
        }
        
        if (progressText && text) {
            progressText.textContent = text;
        }
    },
    
    // Reset app
    resetApp() {
        this.sessionId = null;
        this.videoPath = null;
        this.analysisData = null;
        
        document.getElementById('uploadSection').classList.remove('hidden');
        document.getElementById('processingSection').classList.remove('visible');
        document.getElementById('resultSection').classList.remove('visible');
        document.getElementById('analysisResults').classList.remove('visible');
        document.getElementById('processBtn').style.display = 'none';
        
        // Reset progress
        const steps = ['stepUpload', 'stepAnalyze', 'stepTranscribe', 'stepTranslate', 'stepDub', 'stepMerge'];
        steps.forEach(stepId => {
            this.updateStep(stepId, '');
        });
        
        this.updateProgress(0, 'Preparando...');
        
        // Reset file input
        document.getElementById('fileInput').value = '';
    },
    
    // Utility: Delay
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },
    
    // Utility: Capitalize first letter
    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
