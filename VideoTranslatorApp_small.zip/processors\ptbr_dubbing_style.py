"""
Brazilian Portuguese Dubbing Style Module
Handles voice presets, dubbing styles, and Brazilian-specific dubbing characteristics
to match the quality of professional Brazilian dubbing studios
"""

import os
import logging
import json

logger = logging.getLogger(__name__)

# Brazilian Portuguese Voice Presets
# These presets define voice characteristics for different content types and emotions
PTBR_VOICE_PRESETS = {
    # Character Voices
    'character_male_young': {
        'name': 'Personagem Masculino Jovem',
        'description': 'Voz masculina jovem, típica de anime e cartoons',
        'pitch': 0,
        'speed': 1.0,
        'energy': 0.7,
        'characteristics': 'energetico, voce de identificacao primaria',
        'use_cases': ['anime masculino jovem', 'heroi', 'protagonista']
    },
    'character_male_adult': {
        'name': 'Personagem Masculino Adulto',
        'description': 'Voz masculina adulta, autoritativa',
        'pitch': -2,
        'speed': 0.95,
        'energy': 0.8,
        'characteristics': 'maduro, confiante, autoritario',
        'use_cases': ['pai', 'professor', 'chef', 'vilao']
    },
    'character_male_elder': {
        'name': 'Personagem Masculino Idoso',
        'description': 'Voz masculina idosa, sábia',
        'pitch': -4,
        'speed': 0.85,
        'energy': 0.5,
        'characteristics': 'sabio, calmo, experiencia',
        'use_cases': ['avo', 'sabio', 'conselheiro']
    },
    'character_female_young': {
        'name': 'Personagem Feminino Jovem',
        'description': 'Voz feminina jovem, típicos de anime',
        'pitch': 2,
        'speed': 1.05,
        'energy': 0.7,
        'characteristics': 'animada, alegre, feminina',
        'use_cases': ['anime feminino jovem', 'heroina', 'protagonista']
    },
    'character_female_adult': {
        'name': 'Personagem Feminino Adulto',
        'description': 'Voz feminina adulta, profissional',
        'pitch': 0,
        'speed': 1.0,
        'energy': 0.7,
        'characteristics': 'profissional, confiante, madura',
        'use_cases': ['mae', 'profissional', 'mulher independente']
    },
    'character_female_elder': {
        'name': 'Personagem Feminino Idoso',
        'description': 'Voz feminina idosa, calorosa',
        'pitch': -2,
        'speed': 0.9,
        'energy': 0.5,
        'characteristics': 'calorosa, sabia, amorosa',
        'use_cases': ['avo', 'sabia', 'conselheira']
    },
    
    # Generic/Neutral
    'neutral_male': {
        'name': 'Masculino Neutro',
        'description': 'Voz masculina neutra para narracao',
        'pitch': -1,
        'speed': 0.98,
        'energy': 0.6,
        'characteristics': 'limpo, profissional, neutro',
        'use_cases': ['narracao masculina', 'video institucional']
    },
    'neutral_female': {
        'name': 'Feminino Neutro',
        'description': 'Voz feminina neutra para narracao',
        'pitch': 1,
        'speed': 1.0,
        'energy': 0.6,
        'characteristics': 'limpo, profissional, neutro',
        'use_cases': ['narracao feminina', 'video institucional']
    },
    
    # Specialized Styles
    'dubbing_anime_male': {
        'name': 'Dublagem Anime Masculino',
        'description': 'Estilo brasileiro de dublagem de anime masculino',
        'pitch': 1,
        'speed': 1.02,
        'energy': 0.75,
        'characteristics': 'expressivo, energetico, estilo brasileiro',
        'use_cases': ['anime shonen', 'anime shoujo', 'animacao japonesa'],
        'dubbing_studio_style': 'classic_brasileira'
    },
    'dubbing_anime_female': {
        'name': 'Dublagem Anime Feminino',
        'description': 'Estilo brasileiro de dublagem de anime feminino',
        'pitch': 3,
        'speed': 1.05,
        'energy': 0.7,
        'characteristics': 'expressivo, animodo, estilo brasileiro',
        'use_cases': ['anime shoujo', 'animeJosei', 'animacao japonesa']
    },
    'dubbing_cartoon': {
        'name': 'Dublagem Desenho Animado',
        'description': 'Estilo para desenhos animados',
        'pitch': 2,
        'speed': 1.08,
        'energy': 0.8,
        'characteristics': 'divertido, exagerado, cartunesco',
        'use_cases': ['cartoon', 'desenho infantil', 'animacao ocidental']
    },
    'dubbing_movie_drama': {
        'name': 'Dublagem Filme Drama',
        'description': 'Estilo dramatico para filmes',
        'pitch': 0,
        'speed': 0.95,
        'energy': 0.65,
        'characteristics': 'natural, emocional, profissional',
        'use_cases': ['filme drama', 'seriado', 'cinema']
    },
    'dubbing_movie_action': {
        'name': 'Dublagem Filme Acao',
        'description': 'Estilo para filmes de acao',
        'pitch': -1,
        'speed': 1.0,
        'energy': 0.85,
        'characteristics': 'intenso, energetico, impacto',
        'use_cases': ['filme acao', 'blockbuster', 'super-heroi']
    },
    'dubbing_documentary': {
        'name': 'Documentario',
        'description': 'Estilo para documentarios',
        'pitch': 0,
        'speed': 0.92,
        'energy': 0.5,
        'characteristics': 'serio, informativo, didatico',
        'use_cases': ['documentario', 'video educativo', 'reportagem']
    },
    'dubbing_comedy': {
        'name': 'Comedia',
        'description': 'Estilo comico',
        'pitch': 2,
        'speed': 1.1,
        'energy': 0.8,
        'characteristics': 'varoado, ritmado, comico',
        'use_cases': ['comedia', 'sitcom', 'stand-up']
    },
    'dubbing_romance': {
        'name': 'Romance',
        'description': 'Estilo romantico',
        'pitch': 1,
        'speed': 0.95,
        'energy': 0.5,
        'characteristics': 'suave, emocional, romantico',
        'use_cases': ['romance', 'novela', 'filme romantico']
    },
    'dubbing_horror': {
        'name': 'Terror',
        'description': 'Estilo para terror',
        'pitch': -2,
        'speed': 0.9,
        'energy': 0.6,
        'characteristics': 'sombrio, tenso, misterioso',
        'use_cases': ['terror', 'horror', 'suspense']
    }
}

# Brazilian Portuguese dubbing expressions and adaptations
PTBR_EXPRESSIONS = {
    'slang': {
        'yeah': 'eai',
        'okay': 'ta bom',
        'hey': 'oi',
        'wow': 'nossa',
        'oh': 'ah',
        'yes': 'sim',
        'no': 'nao',
        'thank you': 'obrigado/obrigada',
        'sorry': 'desculpa',
        'great': 'legal',
        'cool': 'massa',
        'awesome': 'incrivel'
    },
    'cultural_adaptations': {
        'hamburger': 'hamburguer',
        'football': 'futebol',
        'soccer': 'futebol',
        'cookie': 'biscoito',
        'movie': 'filme',
        'TV': 'TV',
        'computer': 'computador',
        'cell phone': 'celular',
        'vacation': 'ferias',
        'elevator': 'elevador',
        'apartment': 'apartamento',
        'truck': 'caminhao',
        'hoodie': 'moletom'
    },
    'emotional_expressions': {
        'happy': ['legal!', 'massa!', 'incrivel!', 'que legal!'],
        'sad': ['que triste...', 'nossa...', 'que pena...'],
        'angry': ['nem acredito!', 'isso e demais!', 'vou te mostrar!'],
        'surprised': ['nossa!', 'nao acredito!', 'sério?!', 'como assim?!'],
        'excited': ['vai ser incrivel!', 'mal posso esperar!', 'vamos la!'],
        'fearful': ['ai meu deus!', 'socorro!', 'tem alguém ai?!', 'que medo!']
    }
}

# Dubbing timing rules for Brazilian Portuguese
PTBR_TIMING_RULES = {
    # Brazilian Portuguese is typically 15-20% longer than English
    'expansion_ratio': 1.18,
    
    # Lip-sync tolerance (in frames at 24fps)
    'lipsync_tolerance_frames': 2,
    
    # Sentence pause adjustments
    'pause_short_ms': 150,
    'pause_normal_ms': 300,
    'pause_long_ms': 500,
    
    # Intonation patterns
    'question_rise': 15,  # pitch rise in semitones
    'exclamation_emphasis': 20,  # pitch emphasis
    'statement_fall': -5,  # slight fall
}

# Gender detection mappings for dubbing
GENDER_DUBBING_MAP = {
    'male': {
        'anime': 'dubbing_anime_male',
        'cartoon': 'dubbing_cartoon',
        'movie': 'dubbing_movie_drama',
        'action': 'dubbing_movie_action',
        'documentary': 'neutral_male',
        'comedy': 'dubbing_comedy',
        'romance': 'dubbing_romance',
        'horror': 'dubbing_horror'
    },
    'female': {
        'anime': 'dubbing_anime_female',
        'cartoon': 'dubbing_cartoon',
        'movie': 'dubbing_movie_drama',
        'action': 'dubbing_movie_action',
        'documentary': 'neutral_female',
        'comedy': 'dubbing_comedy',
        'romance': 'dubbing_romance',
        'horror': 'dubbing_horror'
    }
}

def get_voice_preset(preset_name):
    """
    Get a voice preset by name
    
    Args:
        preset_name: Name of the preset
        
    Returns:
        Voice preset dictionary
    """
    return PTBR_VOICE_PRESETS.get(preset_name, PTBR_VOICE_PRESETS['neutral_male'])

def get_voice_preset_for_content(gender, content_type, emotion='neutral'):
    """
    Get appropriate voice preset for content type and gender
    
    Args:
        gender: 'male' or 'female'
        content_type: Type of content (anime, cartoon, movie, etc.)
        emotion: Detected emotion
        
    Returns:
        Voice preset dictionary
    """
    if gender not in GENDER_DUBBING_MAP:
        gender = 'male'  # Default
    
    # Map content type
    content_map = GENDER_DUBBING_MAP[gender]
    
    # Get preset name
    preset_name = content_map.get(content_type, content_map.get('movie', 'neutral_male'))
    
    return PTBR_VOICE_PRESETS.get(preset_name)

def get_all_presets():
    """
    Get all available voice presets
    
    Returns:
        List of all voice presets
    """
    return PTBR_VOICE_PRESETS

def get_presets_by_category():
    """
    Get presets organized by category
    
    Returns:
        Dictionary of presets by category
    """
    return {
        'characters': {
            'male_young': PTBR_VOICE_PRESETS['character_male_young'],
            'male_adult': PTBR_VOICE_PRESETS['character_male_adult'],
            'male_elder': PTBR_VOICE_PRESETS['character_male_elder'],
            'female_young': PTBR_VOICE_PRESETS['character_female_young'],
            'female_adult': PTBR_VOICE_PRESETS['character_female_adult'],
            'female_elder': PTBR_VOICE_PRESETS['character_female_elder']
        },
        'neutral': {
            'male': PTBR_VOICE_PRESETS['neutral_male'],
            'female': PTBR_VOICE_PRESETS['neutral_female']
        },
        'dubbing_styles': {
            'anime_male': PTBR_VOICE_PRESETS['dubbing_anime_male'],
            'anime_female': PTBR_VOICE_PRESETS['dubbing_anime_female'],
            'cartoon': PTBR_VOICE_PRESETS['dubbing_cartoon'],
            'movie_drama': PTBR_VOICE_PRESETS['dubbing_movie_drama'],
            'movie_action': PTBR_VOICE_PRESETS['dubbing_movie_action'],
            'documentary': PTBR_VOICE_PRESETS['dubbing_documentary'],
            'comedy': PTBR_VOICE_PRESETS['dubbing_comedy'],
            'romance': PTBR_VOICE_PRESETS['dubbing_romance'],
            'horror': PTBR_VOICE_PRESETS['dubbing_horror']
        }
    }

def adapt_text_to_ptbr(text, context=None):
    """
    Adapt text to Brazilian Portuguese conventions
    
    Args:
        text: Original text
        context: Optional context for adaptations
        
    Returns:
        Adapted text
    """
    try:
        adapted = text
        
        # Apply slang adaptations
        for eng, ptbr in PTBR_EXPRESSIONS['slang'].items():
            # Case insensitive replacement
            import re
            pattern = r'\b' + re.escape(eng) + r'\b'
            adapted = re.sub(pattern, ptbr, adapted, flags=re.IGNORECASE)
        
        # Apply cultural adaptations
        for eng, ptbr in PTBR_EXPRESSIONS['cultural_adaptations'].items():
            pattern = r'\b' + re.escape(eng) + r'\b'
            adapted = re.sub(pattern, ptbr, adapted, flags=re.IGNORECASE)
        
        return adapted
        
    except Exception as e:
        logger.error(f"Text adaptation error: {str(e)}")
        return text

def get_timing_parameters():
    """
    Get Brazilian Portuguese timing parameters
    
    Returns:
        Timing parameters dictionary
    """
    return PTBR_TIMING_RULES

def calculate_ptbr_duration(original_duration):
    """
    Calculate expected Brazilian Portuguese duration
    
    Args:
        original_duration: Original audio duration in seconds
        
    Returns:
        Expected PTBR duration
    """
    return original_duration * PTBR_TIMING_RULES['expansion_ratio']

def suggest_voice_from_emotion(emotion, gender):
    """
    Suggest voice preset based on emotion and gender
    
    Args:
        emotion: Detected emotion
        gender: 'male' or 'female'
        
    Returns:
        Voice preset name
    """
    emotion_preset_map = {
        'happy': 'character_male_young' if gender == 'male' else 'character_female_young',
        'sad': 'character_male_adult' if gender == 'male' else 'character_female_adult',
        'angry': 'dubbing_movie_action',
        'fearful': 'dubbing_horror',
        'surprised': 'dubbing_cartoon',
        'excited': 'dubbing_anime_male' if gender == 'male' else 'dubbing_anime_female',
        'calm': 'dubbing_documentary',
        'romantic': 'dubbing_romance',
        'dramatic': 'dubbing_movie_drama',
        'comedic': 'dubbing_comedy',
        'neutral': 'neutral_male' if gender == 'male' else 'neutral_female'
    }
    
    return emotion_preset_map.get(emotion, 'neutral_male' if gender == 'male' else 'neutral_female')

def get_brazilian_dubbing_guide():
    """
    Get comprehensive Brazilian dubbing guide
    
    Returns:
        Dictionary with dubbing guidelines
    """
    return {
        'presets': PTBR_VOICE_PRESETS,
        'expressions': PTBR_EXPRESSIONS,
        'timing': PTBR_TIMING_RULES,
        'gender_map': GENDER_DUBBING_MAP,
        'version': '1.0',
        'description': 'Brazilian Portuguese dubbing parameters for AI-powered dubbing'
    }
