"""
Video Merger Module
Merges dubbed audio with video using ffmpeg
"""

import os
import logging
import subprocess
import shutil

# FFmpeg path - usar caminho direto
FFMPEG_PATH = r"C:\Users\Administrador\Desktop\ffmpeg-8.0.1-essentials_build\bin"
FFMPEG_EXE = os.path.join(FFMPEG_PATH, "ffmpeg.exe")

# Check if ffmpeg exists at the path
FFMPEG_AVAILABLE = os.path.exists(FFMPEG_EXE)

logger = logging.getLogger(__name__)

def merge_audio_video(video_path, audio_path, output_path):
    """
    Merge audio with video file
    
    Args:
        video_path: Path to original video
        audio_path: Path to dubbed audio
        output_path: Path for output video
        
    Returns:
        Path to merged video
    """
    if not FFMPEG_AVAILABLE:
        # If ffmpeg not available, just copy the original video
        # This is a fallback for testing without ffmpeg
        logger.warning("FFmpeg not found, copying original video as output")
        import shutil
        shutil.copy(video_path, output_path)
        logger.info(f"Video copied to: {output_path}")
        return output_path
    
    try:
        logger.info(f"Merging video and audio...")
        
        # Use ffmpeg to replace audio track
        cmd = [
            'ffmpeg', '-i', video_path, '-i', audio_path,
            '-c:v', 'copy',
            '-c:a', 'aac',
            '-strict', 'experimental',
            '-map', '0:v:0',
            '-map', '1:a:0',
            '-y', output_path
        ]
        
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True
        )
        
        logger.info(f"Video merged to: {output_path}")
        return output_path
        
    except subprocess.CalledProcessError as e:
        logger.error(f"FFmpeg error: {e.stderr}")
        # Try alternative method
        try:
            cmd = [
                'ffmpeg', '-i', video_path, '-i', audio_path,
                '-c:v', 'copy', '-c:a', 'copy',
                '-y', output_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            logger.info(f"Video merged (copy) to: {output_path}")
            return output_path
        except Exception as e2:
            logger.error(f"Alternative merge also failed: {e2}")
            raise ValueError(f"Failed to merge video: {e2}")
    except FileNotFoundError:
        raise ValueError("FFmpeg not found. Please install ffmpeg.")

def extract_video_without_audio(video_path, output_path):
    """
    Extract video without audio
    
    Args:
        video_path: Path to original video
        output_path: Path for output video
        
    Returns:
        Path to video without audio
    """
    try:
        cmd = [
            'ffmpeg', '-i', video_path,
            '-c:v', 'copy', '-an',
            '-y', output_path
        ]
        
        subprocess.run(cmd, check=True, capture_output=True)
        return output_path
        
    except Exception as e:
        logger.error(f"Error extracting video: {e}")
        raise
