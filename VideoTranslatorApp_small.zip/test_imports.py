# -*- coding: utf-8 -*-
import os
import sys

# Change to the correct directory
os.chdir(r'C:\Users\Administrador\Desktop\VideoTranslatorApp')

results = []

def log(msg):
    results.append(msg)

log('Testing imports...')

try:
    from processors import emotion_analyzer
    log('emotion_analyzer: OK')
except Exception as e:
    log(f'emotion_analyzer: ERROR - {e}')

try:
    from processors import ptbr_dubbing_style
    log('ptbr_dubbing_style: OK')
except Exception as e:
    log(f'ptbr_dubbing_style: ERROR - {e}')

try:
    from processors import voice_cloner
    log('voice_cloner: OK')
except Exception as e:
    log(f'voice_cloner: ERROR - {e}')

try:
    from processors import pro_tts_generator
    log('pro_tts_generator: OK')
except Exception as e:
    log(f'pro_tts_generator: ERROR - {e}')

log('All imports tested')

# Test Flask app
try:
    from app import app
    log('Flask app: OK')
    
    # Try to get the main page
    with app.test_client() as client:
        response = client.get('/')
        log(f'GET / status: {response.status_code}')
        if response.status_code == 200:
            data = response.get_data()
            if b'DubbingAI' in data:
                log('SUCCESS: DubbingAI found in page!')
            else:
                log('Page loaded but DubbingAI not found')
                log(f'Page length: {len(data)} bytes')
        else:
            log(f'ERROR: {response.data[:200]}')
except Exception as e:
    log(f'Flask app ERROR: {e}')
    import traceback
    traceback.print_exc()

# Write results to file
with open('test_results.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(results))

print('Done. Check test_results.txt')
