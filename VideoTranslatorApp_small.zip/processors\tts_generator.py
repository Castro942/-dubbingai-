"""
TTS Generator Module
Generates dubbed audio using text-to-speech
"""

import os
import logging
import numpy as np
from pydub import AudioSegment
from pydub.playback import play
import tempfile

logger = logging.getLogger(__name__)

# Try to import TTS libraries
try:
    from TTS.api import TTS
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
    logger.warning("Coqui TTS not available, using pyttsx3")

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False
    logger.warning("pyttsx3 not available")

def get_tts_engine():
    """
    Get TTS engine
    
    Returns:
        TTS engine instance
    """
    if PYTTSX3_AVAILABLE:
        engine = pyttsx3.init()
        engine.setProperty('rate', 150)
        engine.setProperty('volume', 0.9)
        return engine
    return None

def generate_speech(text, voice_gender="female", lang="pt"):
    """
    Generate speech from text
    
    Args:
        text: Text to synthesize
        voice_gender: 'male' or 'female'
        lang: Language code
        
    Returns:
        Path to generated audio file
    """
    try:
        logger.info(f"Generating speech: {text[:50]}... ({voice_gender})")
        
        # Create temp file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            output_path = tmp.name
        
        if TTS_AVAILABLE:
            # Try Coqui TTS first
            try:
                tts = TTS(model_path="TTS/models--coqui--tts--v1", gpu=False)
                
                # Use Portuguese voice
                if voice_gender == "female":
                    tts.tts_to_file(text=text, file_path=output_path)
                else:
                    tts.tts_to_file(text=text, file_path=output_path)
                    
                logger.info(f"Coqui TTS generated: {output_path}")
                return output_path
            except Exception as e:
                logger.warning(f"Coqui TTS failed: {e}")
        
        if PYTTSX3_AVAILABLE:
            # Use pyttsx3
            engine = get_tts_engine()
            
            # Get available voices
            voices = engine.getProperty('voices')
            
            # Try to find Portuguese voice
            pt_voice = None
            for voice in voices:
                if 'portuguese' in voice.name.lower() or 'brasil' in voice.name.lower():
                    pt_voice = voice.id
                    break
            
            if pt_voice:
                engine.setProperty('voice', pt_voice)
            elif len(voices) > 0:
                # Use first available voice
                engine.setProperty('voice', voices[0].id)
            
            engine.save_to_file(text, output_path)
            engine.runAndWait()
            
            logger.info(f"pyttsx3 generated: {output_path}")
            return output_path
        
        # Fallback: create silent audio
        logger.warning("No TTS available, creating silent placeholder")
        return create_silent_audio(3.0)
        
    except Exception as e:
        logger.error(f"TTS generation error: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_silent_audio(3.0)

def create_silent_audio(duration_seconds):
    """
    Create silent audio file
    
    Args:
        duration_seconds: Duration of silence
        
    Returns:
        Path to silent audio file
    """
    try:
        # Create silent audio
        sample_rate = 22050
        samples = int(duration_seconds * sample_rate)
        silent = np.zeros(samples, dtype=np.int16)
        
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            output_path = tmp.name
        
        import soundfile as sf
        sf.write(output_path, silent, sample_rate)
        
        return output_path
        
    except Exception as e:
        logger.error(f"Error creating silent audio: {e}")
        # Return empty string as last resort
        return ""

def adjust_audio_timing(audio_path, target_duration, output_path=None):
    """
    Adjust audio to match target duration
    
    Args:
        audio_path: Input audio path
        target_duration: Target duration in seconds
        output_path: Output path (optional)
        
    Returns:
        Path to adjusted audio
    """
    try:
        audio = AudioSegment.from_wav(audio_path)
        current_duration = len(audio) / 1000.0
        
        if output_path is None:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                output_path = tmp.name
        
        if abs(current_duration - target_duration) < 0.5:
            # Close enough, just copy
            audio.export(output_path, format="wav")
        elif current_duration < target_duration:
            # Need to extend - repeat audio
            repeat_times = int(target_duration / current_duration) + 1
            extended = audio
            for _ in range(repeat_times):
                extended = extended + audio
            extended[:int(target_duration * 1000)].export(output_path, format="wav")
        else:
            # Need to trim
            audio[:int(target_duration * 1000)].export(output_path, format="wav")
        
        return output_path
        
    except Exception as e:
        logger.error(f"Error adjusting audio timing: {e}")
        return audio_path

def generate_dubbed_audio(translated_text, voice_segments, output_dir):
    """
    Generate dubbed audio matching original voice segments
    
    Args:
        translated_text: Translated text to speak
        voice_segments: List of voice segment dicts with timing and gender
        output_dir: Output directory
        
    Returns:
        Path to final dubbed audio file
    """
    try:
        logger.info(f"Generating dubbed audio for {len(voice_segments)} segments")
        
        # Simple approach: generate full translation and adjust timing
        if not voice_segments:
            # Default: single segment
            voice_segments = [{
                'start_time': 0.0,
                'end_time': 10.0,
                'gender': 'female'
            }]
        
        # Get dominant gender
        male_count = sum(1 for s in voice_segments if s.get('gender') == 'male')
        female_count = sum(1 for s in voice_segments if s.get('gender') == 'female')
        
        dominant_gender = 'female'
        if male_count > female_count:
            dominant_gender = 'male'
        
        logger.info(f"Using {dominant_gender} voice for dubbing")
        
        # Generate speech with dominant gender
        speech_file = generate_speech(translated_text, dominant_gender, "pt")
        
        if not speech_file or speech_file == "":
            logger.warning("Speech generation failed, creating placeholder")
            # Create placeholder audio matching video duration
            total_duration = max(s.get('end_time', 0) for s in voice_segments) if voice_segments else 10.0
            speech_file = create_silent_audio(total_duration)
        
        # Adjust timing to match original audio duration
        if voice_segments:
            total_duration = max(s.get('end_time', 0) for s in voice_segments)
            speech_file = adjust_audio_timing(speech_file, total_duration)
        
        # Copy to output directory
        final_output = os.path.join(output_dir, "dubbed_audio.wav")
        
        try:
            audio = AudioSegment.from_wav(speech_file)
            audio.export(final_output, format="wav")
        except:
            # If adjustment failed, just copy
            import shutil
            shutil.copy(speech_file, final_output)
        
        logger.info(f"Dubbed audio saved to: {final_output}")
        return final_output
        
    except Exception as e:
        logger.error(f"Dubbed audio generation error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Return silent audio as fallback
        return create_silent_audio(10.0)

def mix_audio_with_sfx(original_audio_path, dubbed_audio_path, output_path, sfx_volume=0.3):
    """
    Mix dubbed audio with original audio (preserving sound effects)
    
    Args:
        original_audio_path: Original audio with sound effects
        dubbed_audio_path: Dubbed voice audio
        output_path: Output path
        sfx_volume: Volume of original audio (sound effects)
        
    Returns:
        Path to mixed audio
    """
    try:
        logger.info("Mixing dubbed audio with sound effects...")
        
        original = AudioSegment.from_wav(original_audio_path)
        dubbed = AudioSegment.from_wav(dubbed_audio_path)
        
        # Adjust dubbed audio to match original duration
        if len(dubbed) < len(original):
            # Pad with silence
            padding = AudioSegment.silent(duration=len(original) - len(dubbed))
            dubbed = dubbed + padding
        elif len(dubbed) > len(original):
            # Trim
            dubbed = dubbed[:len(original)]
        
        # Lower original volume for sound effects
        original_reduced = original - 20  # Reduce by 20dB
        
        # Mix: dubbed voice + reduced original (sfx)
        # Use original as base, overlay dubbed
        mixed = original_reduced.overlay(dubbed)
        
        mixed.export(output_path, format="wav")
        
        logger.info(f"Mixed audio saved to: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"Audio mixing error: {str(e)}")
        # Return dubbed audio as fallback
        import shutil
        shutil.copy(dubbed_audio_path, output_path)
        return output_path
