"""
Professional TTS Generator Module
Advanced text-to-speech generation with emotion preservation and voice cloning
for Brazilian Portuguese professional dubbing
"""

import os
import logging
import json
import tempfile
import numpy as np
from pydub import AudioSegment
import soundfile as sf

logger = logging.getLogger(__name__)

# Import our custom modules
try:
    from processors.emotion_analyzer import get_emotion_for_tts, EMOTION_CATEGORIES
    from processors.ptbr_dubbing_style import (
        get_voice_preset, 
        get_voice_preset_for_content,
        adapt_text_to_ptbr,
        suggest_voice_from_emotion
    )
    from processors.voice_cloner import (
        get_voice_conversion_parameters,
        apply_voice_characteristics
    )
    CUSTOM_MODULES_AVAILABLE = True
except ImportError:
    CUSTOM_MODULES_AVAILABLE = False
    logger.warning("Custom modules not available, using basic TTS")

# Try to import TTS libraries
try:
    from TTS.api import TTS
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
    logger.warning("Coqui TTS not available")

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False

# Try to import bark
try:
    from bark import generate_audio
    BARK_AVAILABLE = True
except ImportError:
    BARK_AVAILABLE = False

# Try to import edge-tts
try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False


class ProfessionalTTSEngine:
    """
    Professional TTS Engine for Brazilian Portuguese dubbing
    Supports emotion preservation, voice cloning, and multiple TTS backends
    """
    
    def __init__(self, config=None):
        self.config = config or {}
        self.tts_engine = None
        self.edge_voice = None
        self.current_voice_profile = None
        self.current_emotion = None
        
    def initialize(self, backend='edge'):
        """
        Initialize TTS engine with specified backend
        
        Args:
            backend: 'coqui', 'edge', 'bark', or 'pyttsx3'
        """
        try:
            if backend == 'coqui' and TTS_AVAILABLE:
                logger.info("Initializing Coqui TTS engine")
                self.tts_engine = TTS(model_path="TTS/models--coqui--tts--v1", gpu=False)
                
            elif backend == 'edge' and EDGE_TTS_AVAILABLE:
                logger.info("Edge TTS available")
                # Edge TTS doesn't need initialization
                
            elif backend == 'bark' and BARK_AVAILABLE:
                logger.info("Bark TTS available")
                
            elif backend == 'pyttsx3' and PYTTSX3_AVAILABLE:
                logger.info("Initializing pyttsx3 engine")
                self.tts_engine = pyttsx3.init()
                self.tts_engine.setProperty('rate', 150)
                self.tts_engine.setProperty('volume', 0.9)
                
            else:
                logger.warning(f"Backend {backend} not available, using fallback")
                return False
                
            self.backend = backend
            return True
            
        except Exception as e:
            logger.error(f"TTS initialization error: {str(e)}")
            return False
    
    def set_voice_preset(self, preset_name):
        """Set voice preset for TTS generation"""
        if CUSTOM_MODULES_AVAILABLE:
            self.current_voice_profile = get_voice_preset(preset_name)
        else:
            self.current_voice_profile = {'pitch': 0, 'speed': 1.0, 'energy': 0.7}
    
    def set_emotion(self, emotion_data):
        """Set emotion parameters for TTS generation"""
        if CUSTOM_MODULES_AVAILABLE and emotion_data:
            self.current_emotion = get_emotion_for_tts(emotion_data)
        else:
            self.current_emotion = {
                'emotion': 'neutral',
                'intensity': 0.5,
                'pitch_modifier': 1.0,
                'rate_modifier': 1.0
            }
    
    def generate(self, text, voice_preset=None, emotion_data=None, output_path=None):
        """
        Generate speech with emotion and voice settings
        
        Args:
            text: Text to synthesize
            voice_preset: Voice preset name
            emotion_data: Emotion analysis data
            output_path: Output file path
            
        Returns:
            Path to generated audio
        """
        try:
            # Apply voice preset
            if voice_preset:
                self.set_voice_preset(voice_preset)
            
            # Apply emotion
            if emotion_data:
                self.set_emotion(emotion_data)
            
            # Get parameters
            preset = self.current_voice_profile or {'pitch': 0, 'speed': 1.0}
            emotion = self.current_emotion or {'emotion': 'neutral', 'rate_modifier': 1.0}
            
            # Adapt text to Brazilian Portuguese
            if CUSTOM_MODULES_AVAILABLE:
                text = adapt_text_to_ptbr(text)
            
            # Generate audio
            if output_path is None:
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                    output_path = tmp.name
            
            # Try different backends
            success = False
            
            # Try Edge TTS (best quality for PT-BR)
            if EDGE_TTS_AVAILABLE and not success:
                success = self._generate_edge_tts(text, output_path, preset, emotion)
            
            # Try Coqui TTS
            if TTS_AVAILABLE and not success:
                success = self._generate_coqui_tts(text, output_path, preset, emotion)
            
            # Try Bark
            if BARK_AVAILABLE and not success:
                success = self._generate_bark(text, output_path, preset, emotion)
            
            # Fallback to pyttsx3
            if PYTTSX3_AVAILABLE and not success:
                success = self._generate_pyttsx3(text, output_path, preset)
            
            if not success:
                logger.warning("All TTS backends failed, creating placeholder")
                return self._create_placeholder_audio(3.0)
            
            return output_path
            
        except Exception as e:
            logger.error(f"TTS generation error: {str(e)}")
            import traceback
            traceback.print_exc()
            return self._create_placeholder_audio(3.0)
    
    def _generate_edge_tts(self, text, output_path, preset, emotion):
        """Generate using Edge TTS"""
        try:
            import asyncio
            
            # Map emotion to Edge TTS voice styles
            voice_map = {
                'neutral': 'pt-BR-FranciscaNeural',
                'happy': 'pt-BR-FranciscaNeural',
                'sad': 'pt-BR-AntonioNeural',
                'angry': 'pt-BR-AntonioNeural',
                'calm': 'pt-BR-FranciscaNeural',
            }
            
            # Select voice based on gender from preset
            pitch = preset.get('pitch', 0)
            if pitch > 0:
                voice = 'pt-BR-FranciscaNeural'  # Female
            else:
                voice = 'pt-BR-AntonioNeural'  # Male
            
            # Adjust rate based on emotion
            rate = emotion.get('rate_modifier', 1.0)
            rate_str = "+0%" if rate >= 1.0 else f"-{int((1-rate)*100)}%"
            
            # Apply pitch modification
            pitch_val = preset.get('pitch', 0)
            pitch_str = f"+{pitch_val}Hz" if pitch_val >= 0 else f"{pitch_val}Hz"
            
            async def generate():
                communicate = edge_tts.Communicate(text, voice, rate=rate_str, pitch=pitch_str)
                await communicate.save(output_path)
            
            asyncio.run(generate())
            
            logger.info(f"Edge TTS generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Edge TTS error: {str(e)}")
            return False
    
    def _generate_coqui_tts(self, text, output_path, preset, emotion):
        """Generate using Coqui TTS"""
        try:
            # Apply emotion modifications
            pitch_shift = preset.get('pitch', 0) + (emotion.get('pitch_modifier', 1.0) - 1.0) * 10
            
            self.tts_engine.tts_to_file(
                text=text,
                file_path=output_path,
                pitch=pitch_shift,
                speed=preset.get('speed', 1.0) * emotion.get('rate_modifier', 1.0)
            )
            
            logger.info(f"Coqui TTS generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Coqui TTS error: {str(e)}")
            return False
    
    def _generate_bark(self, text, output_path, preset, emotion):
        """Generate using Bark"""
        try:
            # Bark supports emotion prompts
            emotion_prompts = {
                'neutral': 'neutral speech',
                'happy': '[happy] cheerful speech',
                'sad': '[sad] melancholic speech',
                'angry': '[angry] furious speech',
                'fearful': '[fearful] terrified speech',
                'surprised': '[surprised] amazed speech',
                'calm': '[calm] peaceful speech'
            }
            
            prompt = emotion_prompts.get(emotion.get('emotion', 'neutral'), 'neutral speech')
            
            # Generate audio
            audio_array = generate_audio(f"{prompt} {text}")
            
            # Save
            sf.write(output_path, audio_array, 24000)
            
            logger.info(f"Bark TTS generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Bark TTS error: {str(e)}")
            return False
    
    def _generate_pyttsx3(self, text, output_path, preset):
        """Generate using pyttsx3"""
        try:
            engine = pyttsx3.init()
            
            # Set rate
            rate = int(150 * preset.get('speed', 1.0))
            engine.setProperty('rate', rate)
            
            # Get voices and try to find Portuguese
            voices = engine.getProperty('voices')
            pt_voice = None
            
            for voice in voices:
                if 'portuguese' in voice.name.lower() or 'brasil' in voice.name.lower():
                    pt_voice = voice.id
                    break
            
            if pt_voice:
                engine.setProperty('voice', pt_voice)
            elif len(voices) > 0:
                # Use first available
                engine.setProperty('voice', voices[0].id)
            
            engine.save_to_file(text, output_path)
            engine.runAndWait()
            
            logger.info(f"pyttsx3 generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"pyttsx3 error: {str(e)}")
            return False
    
    def _create_placeholder_audio(self, duration):
        """Create placeholder silent audio"""
        try:
            sample_rate = 22050
            samples = int(duration * sample_rate)
            silent = np.zeros(samples, dtype=np.int16)
            
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                output_path = tmp.name
            
            sf.write(output_path, silent, sample_rate)
            return output_path
            
        except Exception as e:
            logger.error(f"Placeholder creation error: {str(e)}")
            return ""


# Global TTS engine instance
_tts_engine = None

def get_tts_engine():
    """Get or create global TTS engine"""
    global _tts_engine
    if _tts_engine is None:
        _tts_engine = ProfessionalTTSEngine()
        # Try to initialize with best available backend
        for backend in ['edge', 'coqui', 'bark', 'pyttsx3']:
            if _tts_engine.initialize(backend):
                break
    return _tts_engine


def generate_professional_speech(
    text,
    voice_preset=None,
    emotion_data=None,
    voice_profile=None,
    output_dir=None,
    session_id=None
):
    """
    Generate professional Brazilian Portuguese speech with emotion preservation
    
    Args:
        text: Text to synthesize
        voice_preset: Voice preset name from PTBR styles
        emotion_data: Emotion analysis result
        voice_profile: Voice profile for cloning
        output_dir: Output directory
        session_id: Session ID
        
    Returns:
        Path to generated audio
    """
    try:
        logger.info(f"Generating professional speech: {text[:50]}...")
        
        # Get TTS engine
        engine = get_tts_engine()
        
        # Set voice preset
        if voice_preset:
            engine.set_voice_preset(voice_preset)
        
        # Set emotion
        if emotion_data:
            engine.set_emotion(emotion_data)
        
        # Generate output path
        if output_dir is None:
            output_dir = tempfile.gettempdir()
        
        output_path = os.path.join(output_dir, f"tts_{session_id or 'output'}.wav")
        
        # Generate audio
        audio_path = engine.generate(
            text=text,
            voice_preset=voice_preset,
            emotion_data=emotion_data,
            output_path=output_path
        )
        
        # Apply voice cloning if available
        if voice_profile and CUSTOM_MODULES_AVAILABLE:
            try:
                temp_path = audio_path
                audio_path = os.path.join(output_dir, f"cloned_{session_id or 'output'}.wav")
                apply_voice_characteristics(temp_path, voice_profile, audio_path)
            except Exception as e:
                logger.warning(f"Voice cloning failed: {str(e)}")
        
        return audio_path
        
    except Exception as e:
        logger.error(f"Professional speech generation error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Return silent placeholder
        sample_rate = 22050
        silent = np.zeros(int(3 * sample_rate), dtype=np.int16)
        
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            output_path = tmp.name
        
        sf.write(output_path, silent, sample_rate)
        return output_path


def generate_segmented_dubbed_audio(
    translated_segments,
    voice_segments,
    emotion_analysis,
    voice_profiles,
    output_dir
):
    """
    Generate dubbed audio with different voices for each segment
    
    Args:
        translated_segments: List of translated text segments with timestamps
        voice_segments: List of voice/gender segments
        emotion_analysis: Emotion analysis result
        voice_profiles: Voice profiles for cloning
        output_dir: Output directory
        
    Returns:
        Path to final dubbed audio
    """
    try:
        logger.info(f"Generating segmented dubbed audio for {len(translated_segments)} segments")
        
        if not translated_segments:
            return create_silent_audio(5.0)
        
        # Process each segment
        segment_audio_paths = []
        
        for i, segment in enumerate(translated_segments):
            text = segment.get('text', '')
            start_time = segment.get('start', i * 3)
            end_time = segment.get('end', start_time + 3)
            duration = end_time - start_time
            
            if not text:
                # Silent segment
                segment_audio_paths.append({
                    'path': create_silent_audio(duration),
                    'start': start_time,
                    'end': end_time
                })
                continue
            
            # Get corresponding voice/gender
            voice_gender = 'male'
            voice_preset = 'neutral_male'
            
            for vs in voice_segments:
                if vs.get('start_time', 0) <= start_time < vs.get('end_time', 999):
                    voice_gender = vs.get('gender', 'male')
                    break
            
            # Get emotion for this segment
            segment_emotion = None
            if emotion_analysis and emotion_analysis.get('segment_emotions'):
                for em in emotion_analysis.get('segment_emotions'):
                    if em.get('start_time', 0) <= start_time < em.get('end_time', 999):
                        segment_emotion = {'emotion': em.get('emotion', 'neutral')}
                        break
            
            # Get voice profile
            segment_profile = None
            if voice_profiles and len(voice_profiles) > i % len(voice_profiles):
                segment_profile = voice_profiles[i % len(voice_profiles)]
            
            # Get voice preset
            if CUSTOM_MODULES_AVAILABLE:
                voice_preset = suggest_voice_from_emotion(
                    segment_emotion.get('emotion', 'neutral') if segment_emotion else 'neutral',
                    voice_gender
                )
            
            # Generate speech
            audio_path = generate_professional_speech(
                text=text,
                voice_preset=voice_preset,
                emotion_data=segment_emotion,
                voice_profile=segment_profile,
                output_dir=output_dir,
                session_id=f"seg_{i}"
            )
            
            # Adjust timing if needed
            if audio_path:
                from processors.tts_generator import adjust_audio_timing
                audio_path = adjust_audio_timing(audio_path, duration)
            
            segment_audio_paths.append({
                'path': audio_path,
                'start': start_time,
                'end': end_time
            })
        
        # Merge all segments
        final_audio = merge_audio_segments(segment_audio_paths, output_dir)
        
        return final_audio
        
    except Exception as e:
        logger.error(f"Segmented dubbing error: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_silent_audio(10.0)


def merge_audio_segments(segments, output_dir):
    """
    Merge multiple audio segments into one
    
    Args:
        segments: List of segment dictionaries with path, start, end
        output_dir: Output directory
        
    Returns:
        Path to merged audio
    """
    try:
        if not segments:
            return create_silent_audio(5.0)
        
        # Load first segment
        first_path = segments[0].get('path')
        if not first_path or not os.path.exists(first_path):
            return create_silent_audio(5.0)
        
        combined = AudioSegment.from_wav(first_path)
        
        # Add remaining segments
        for segment in segments[1:]:
            path = segment.get('path')
            if path and os.path.exists(path):
                audio = AudioSegment.from_wav(path)
                combined = combined + audio
            else:
                # Add silence
                silence = AudioSegment.silent(duration=3000)
                combined = combined + silence
        
        # Export
        output_path = os.path.join(output_dir, "merged_dubbed.wav")
        combined.export(output_path, format="wav")
        
        return output_path
        
    except Exception as e:
        logger.error(f"Audio merge error: {str(e)}")
        return segments[0].get('path') if segments else create_silent_audio(5.0)


def create_silent_audio(duration_seconds):
    """Create silent audio file"""
    try:
        sample_rate = 22050
        samples = int(duration_seconds * sample_rate)
        silent = np.zeros(samples, dtype=np.int16)
        
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            output_path = tmp.name
        
        sf.write(output_path, silent, sample_rate)
        return output_path
        
    except Exception as e:
        logger.error(f"Silent audio error: {str(e)}")
        return ""
