#!/usr/bin/env python
"""Test script to verify DubbingAI Pro app"""

import sys
sys.path.insert(0, '.')

from app import app

def test_endpoints():
    print("Testing DubbingAI Pro Endpoints...")
    print("-" * 40)
    
    with app.test_client() as client:
        # Test main page
        r = client.get('/')
        status = "OK" if r.status_code == 200 else "FAIL"
        print(f"[{status}] GET / - Status: {r.status_code}")
        
        # Test presets API
        r = client.get('/api/presets')
        status = "OK" if r.status_code == 200 else "FAIL"
        print(f"[{status}] GET /api/presets - Status: {r.status_code}")
        
        # Test emotions API
        r = client.get('/api/emotions')
        status = "OK" if r.status_code == 200 else "FAIL"
        print(f"[{status}] GET /api/emotions - Status: {r.status_code}")
        
        # Test upload endpoint (should fail without file)
        r = client.post('/api/upload')
        status = "OK" if r.status_code == 400 else "FAIL"
        print(f"[{status}] POST /api/upload (no file) - Status: {r.status_code}")
        
    print("-" * 40)
    print("All tests completed!")
    return True

if __name__ == '__main__':
    test_endpoints()
