import os
import sys

# Change to the correct directory
os.chdir(r'C:\Users\Administrador\Desktop\VideoTranslatorApp')
sys.path.insert(0, '.')

# Run the Flask app
from app import app

print("\n" + "="*50)
print("DUBBINGAI PRO - SERVIDOR INICIADO")
print("="*50)
print("\nAcesse no navegador: http://localhost:5000")
print("Pressione CTRL+C para parar\n")

app.run(host='0.0.0.0', port=5000, debug=False)
