# -*- coding: utf-8 -*-
"""Test AI processors for DubbingAI"""
import os
import sys

# Change to correct directory
os.chdir(r'C:\Users\Administrador\Desktop\VideoTranslatorApp')
sys.path.insert(0, '.')

results = []

def log(msg):
    results.append(str(msg))

log("=" * 50)
log("DUBBINGAI PRO - TESTE DE IA")
log("=" * 50)

# Test emotion analyzer
log("\n[1] Testando Emotion Analyzer...")
try:
    from processors.emotion_analyzer import EMOTION_CATEGORIES, analyze_emotions
    log(f"   Emotions loaded: {len(EMOTION_CATEGORIES)} categories")
    log("   Emotions: " + ", ".join(EMOTION_CATEGORIES[:6]) + "...")
    log("   ✓ Emotion Analyzer OK")
except Exception as e:
    log(f"   ✗ Error: {e}")

# Test PT-BR dubbing styles
log("\n[2] Testando Estilos de Dublagem PT-BR...")
try:
    from processors.ptbr_dubbing_style import get_all_presets, get_presets_by_category
    presets = get_all_presets()
    categories = get_presets_by_category()
    log(f"   Presets loaded: {len(presets)}")
    log(f"   Categories: {list(categories.keys())}")
    log("   ✓ PT-BR Styles OK")
except Exception as e:
    log(f"   ✗ Error: {e}")

# Test voice cloner
log("\n[3] Testando Clonagem de Voz...")
try:
    from processors.voice_cloner import extract_voice_characteristics
    log("   Voice cloner functions loaded")
    log("   ✓ Voice Cloner OK")
except Exception as e:
    log(f"   ✗ Error: {e}")

# Test TTS Generator
log("\n[4] Testando TTS Profissional...")
try:
    from processors.pro_tts_generator import get_available_voices, EDGE_VOICES
    log(f"   Edge TTS voices: {len(EDGE_VOICES)}")
    log("   ✓ TTS Generator OK")
except Exception as e:
    log(f"   ✗ Error: {e}")

# Test Flask app
log("\n[5] Testando Servidor Flask...")
try:
    from app import app
    log("   Flask app imported OK")
    
    # Test routes
    with app.test_client() as client:
        r = client.get('/')
        log(f"   GET / status: {r.status_code}")
        
        if r.status_code == 200 and b'DubbingAI' in r.data:
            log("   ✓ Servidor OK - Página principal carrega!")
        else:
            log("   ✗ Problema ao carregar página")
except Exception as e:
    log(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()

log("\n" + "=" * 50)
log("TESTE CONCLUÍDO")
log("=" * 50)

# Save results
with open('ai_test_results.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(results))

print('\n'.join(results))
