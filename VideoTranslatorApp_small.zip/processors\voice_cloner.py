"""
Voice Cloning Module
Creates voice profiles from source audio to preserve original voice characteristics
during dubbing, maintaining the speaker's unique timbre
"""

import os
import logging
import json
import numpy as np
from pydub import AudioSegment

try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False

try:
    import soundfile as sf
    SOUNDFILE_AVAILABLE = True
except ImportError:
    SOUNDFILE_AVAILABLE = False

logger = logging.getLogger(__name__)

# Voice profile storage
VOICE_PROFILES_DIR = os.path.join(os.path.dirname(__file__), '..', 'static', 'voice_profiles')
os.makedirs(VOICE_PROFILES_DIR, exist_ok=True)

class VoiceProfile:
    """Represents a voice profile with unique characteristics"""
    
    def __init__(self, name=None):
        self.name = name
        self.mean_pitch = 0.0
        self.pitch_range = 0.0
        self.formant_frequencies = []
        self.spectral_features = {}
        self.timbre_signature = {}
        self.gender = 'unknown'
        self.age_group = 'adult'
        self.confidence = 0.0
        
    def to_dict(self):
        return {
            'name': self.name,
            'mean_pitch': self.mean_pitch,
            'pitch_range': self.pitch_range,
            'formant_frequencies': self.formant_frequencies,
            'spectral_features': self.spectral_features,
            'timbre_signature': self.timbre_signature,
            'gender': self.gender,
            'age_group': self.age_group,
            'confidence': self.confidence
        }
    
    @classmethod
    def from_dict(cls, data):
        profile = cls(data.get('name'))
        profile.mean_pitch = data.get('mean_pitch', 0.0)
        profile.pitch_range = data.get('pitch_range', 0.0)
        profile.formant_frequencies = data.get('formant_frequencies', [])
        profile.spectral_features = data.get('spectral_features', {})
        profile.timbre_signature = data.get('timbre_signature', {})
        profile.gender = data.get('gender', 'unknown')
        profile.age_group = data.get('age_group', 'adult')
        profile.confidence = data.get('confidence', 0.0)
        return profile


def extract_voice_characteristics(audio_path, sample_duration=30.0):
    """
    Extract unique voice characteristics from audio sample
    
    Args:
        audio_path: Path to audio file
        sample_duration: Duration to sample in seconds (default 30s)
        
    Returns:
        VoiceProfile object with extracted characteristics
    """
    try:
        logger.info(f"Extracting voice characteristics from: {audio_path}")
        
        profile = VoiceProfile()
        
        if not LIBROSA_AVAILABLE:
            logger.warning("librosa not available, using basic extraction")
            return basic_voice_extraction(audio_path)
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050, duration=sample_duration)
        
        # Extract fundamental frequency (F0)
        hop_length = 512
        f0, voiced_flag, voiced_probs = librosa.pyin(
            y, fmin=50, fmax=500, sr=sr, hop_length=hop_length
        )
        
        # Get valid F0 values
        f0_valid = f0[~np.isnan(f0)]
        
        if len(f0_valid) > 0:
            profile.mean_pitch = float(np.median(f0_valid))
            profile.pitch_range = float(np.std(f0_valid))
            profile.pitch_range = float(np.max(f0_valid) - np.min(f0_valid))
            
            # Determine gender from pitch
            if profile.mean_pitch < 180:
                profile.gender = 'male'
            else:
                profile.gender = 'female'
            
            profile.confidence = 0.8
        else:
            logger.warning("No valid pitch detected, using default profile")
            return basic_voice_extraction(audio_path)
        
        # Extract spectral features (MFCCs)
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        profile.spectral_features = {
            'mfcc_mean': [float(np.mean(mfcc)) for mfcc in mfccs],
            'mfcc_std': [float(np.std(mfcc)) for mfcc in mfccs],
            'mfcc_delta_mean': [float(np.mean(d)) for d in librosa.feature.delta(mfccs)]
        }
        
        # Extract formants (simplified - using spectral peaks)
        S = np.abs(librosa.stft(y))
        spectral_peaks = np.argsort(S.mean(axis=1))[-5:]  # Top 5 frequencies
        profile.formant_frequencies = [float(f * sr / S.shape[0]) for f in spectral_peaks]
        
        # Extract timbre signature
        # Using spectral centroid, bandwidth, rolloff
        centroid = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
        bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr)[0]
        rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)[0]
        
        profile.timbre_signature = {
            'centroid_mean': float(np.mean(centroid)),
            'centroid_std': float(np.std(centroid)),
            'bandwidth_mean': float(np.mean(bandwidth)),
            'rolloff_mean': float(np.mean(rolloff)),
            'zero_crossing_rate': float(np.mean(librosa.feature.zero_crossing_rate(y)[0]))
        }
        
        # Determine age group (simplified)
        if profile.mean_pitch > 200:
            profile.age_group = 'young'
        elif profile.mean_pitch < 120:
            profile.age_group = 'elder'
        else:
            profile.age_group = 'adult'
        
        logger.info(f"Voice characteristics extracted: gender={profile.gender}, pitch={profile.mean_pitch:.1f}Hz")
        
        return profile
        
    except Exception as e:
        logger.error(f"Voice characteristic extraction error: {str(e)}")
        import traceback
        traceback.print_exc()
        return basic_voice_extraction(audio_path)


def basic_voice_extraction(audio_path):
    """
    Basic voice extraction without librosa
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Basic VoiceProfile
    """
    try:
        audio = AudioSegment.from_wav(audio_path)
        
        profile = VoiceProfile()
        
        # Basic frequency estimation
        samples = np.array(audio.get_array_of_samples())
        sample_rate = audio.frame_rate
        
        # Simple zero crossing rate for basic characterization
        zero_crossings = np.sum(np.diff(np.sign(samples)) != 0)
        zcr = zero_crossings / len(samples)
        
        # Estimate pitch from energy
        energy = np.abs(samples).mean()
        
        # Very basic gender detection
        if zcr > 0.1 and energy < 10000:
            profile.gender = 'female'
            profile.mean_pitch = 200.0
        else:
            profile.gender = 'male'
            profile.mean_pitch = 120.0
        
        profile.confidence = 0.4
        profile.pitch_range = 50.0
        
        return profile
        
    except Exception as e:
        logger.error(f"Basic voice extraction error: {str(e)}")
        
        # Return default profile
        profile = VoiceProfile()
        profile.gender = 'male'
        profile.mean_pitch = 140.0
        profile.confidence = 0.3
        return profile


def save_voice_profile(profile, session_id):
    """
    Save voice profile to disk
    
    Args:
        profile: VoiceProfile object
        session_id: Session identifier
        
    Returns:
        Path to saved profile
    """
    try:
        profile_path = os.path.join(VOICE_PROFILES_DIR, f"{session_id}_profile.json")
        
        with open(profile_path, 'w', encoding='utf-8') as f:
            json.dump(profile.to_dict(), f, indent=2, ensure_ascii=False)
        
        logger.info(f"Voice profile saved: {profile_path}")
        return profile_path
        
    except Exception as e:
        logger.error(f"Error saving voice profile: {str(e)}")
        return None


def load_voice_profile(session_id):
    """
    Load voice profile from disk
    
    Args:
        session_id: Session identifier
        
    Returns:
        VoiceProfile object or None
    """
    try:
        profile_path = os.path.join(VOICE_PROFILES_DIR, f"{session_id}_profile.json")
        
        if not os.path.exists(profile_path):
            return None
        
        with open(profile_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return VoiceProfile.from_dict(data)
        
    except Exception as e:
        logger.error(f"Error loading voice profile: {str(e)}")
        return None


def get_voice_conversion_parameters(source_profile, target_voice_preset):
    """
    Calculate parameters to convert TTS voice to match source voice
    
    Args:
        source_profile: VoiceProfile of source speaker
        target_voice_preset: Target voice preset parameters
        
    Returns:
        Dictionary with conversion parameters
    """
    try:
        # Get target characteristics
        target_pitch = 140 if target_voice_preset.get('gender', 'male') == 'male' else 200
        target_pitch += target_voice_preset.get('pitch', 0)
        
        # Calculate pitch adjustment
        pitch_adjustment = source_profile.mean_pitch / target_pitch if target_pitch > 0 else 1.0
        
        # Speed adjustment based on timbre
        speed_mod = target_voice_preset.get('speed', 1.0)
        
        # Energy adjustment
        energy_mod = target_voice_preset.get('energy', 0.7)
        
        conversion_params = {
            'pitch_ratio': pitch_adjustment,
            'speed_modifier': speed_mod,
            'energy_modifier': energy_mod,
            'gender': source_profile.gender,
            'source_pitch': source_profile.mean_pitch,
            'target_pitch': target_pitch,
            'confidence': source_profile.confidence
        }
        
        return conversion_params
        
    except Exception as e:
        logger.error(f"Voice conversion parameter calculation error: {str(e)}")
        return {
            'pitch_ratio': 1.0,
            'speed_modifier': 1.0,
            'energy_modifier': 0.7,
            'gender': 'male',
            'confidence': 0.5
        }


def create_multi_voice_profile(audio_path, num_speakers=2):
    """
    Create voice profiles for multiple speakers in audio
    
    Args:
        audio_path: Path to audio file
        num_speakers: Number of speakers to detect (default 2)
        
    Returns:
        List of VoiceProfile objects
    """
    try:
        logger.info(f"Creating multi-voice profile for {num_speakers} speakers")
        
        if not LIBROSA_AVAILABLE:
            # Return basic profiles
            return [basic_voice_extraction(audio_path) for _ in range(num_speakers)]
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050)
        duration = len(y) / sr
        
        # Simple segmentation by energy
        # In production, would use speaker diarization
        segment_duration = duration / num_speakers
        
        profiles = []
        
        for i in range(num_speakers):
            start = int(i * segment_duration * sr)
            end = int((i + 1) * segment_duration * sr)
            
            segment = y[start:end]
            
            # Save temporary segment
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
                temp_path = tmp.name
            
            sf.write(temp_path, segment, sr)
            
            # Extract profile
            profile = extract_voice_characteristics(temp_path)
            profile.name = f"speaker_{i+1}"
            
            profiles.append(profile)
            
            # Cleanup
            try:
                os.remove(temp_path)
            except:
                pass
        
        logger.info(f"Created {len(profiles)} voice profiles")
        return profiles
        
    except Exception as e:
        logger.error(f"Multi-voice profile creation error: {str(e)}")
        return [basic_voice_extraction(audio_path)]


def apply_voice_characteristics(audio_path, source_profile, output_path):
    """
    Apply source voice characteristics to generated audio
    
    Args:
        audio_path: Path to generated audio
        source_profile: Source voice profile to match
        output_path: Path for output audio
        
    Returns:
        Path to adjusted audio
    """
    try:
        logger.info("Applying voice characteristics")
        
        if not LIBROSA_AVAILABLE:
            # Basic adjustment without librosa
            import shutil
            shutil.copy(audio_path, output_path)
            return output_path
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050)
        
        # Apply pitch shift based on source profile
        # This is a simplified version - real voice conversion would be more complex
        target_pitch = source_profile.mean_pitch
        
        # Estimate current pitch
        f0, _, _ = librosa.pyin(y, fmin=50, fmax=500, sr=sr)
        f0_valid = f0[~np.isnan(f0)]
        
        if len(f0_valid) > 0:
            current_pitch = np.median(f0_valid)
            pitch_ratio = target_pitch / current_pitch if current_pitch > 0 else 1.0
            
            # Apply pitch shift (using phase vocoder for better quality)
            # Note: In production, would use a proper voice conversion model
            y_shifted = librosa.effects.pitch_shift(y, sr, n_steps=12 * np.log2(pitch_ratio))
        else:
            y_shifted = y
        
        # Save result
        sf.write(output_path, y_shifted, sr)
        
        logger.info(f"Voice characteristics applied: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"Voice characteristic application error: {str(e)}")
        import shutil
        shutil.copy(audio_path, output_path)
        return output_path


def generate_voice_profile_summary(profiles):
    """
    Generate summary of voice profiles
    
    Args:
        profiles: List of VoiceProfile objects
        
    Returns:
        Summary dictionary
    """
    if not profiles:
        return {'count': 0}
    
    if isinstance(profiles, VoiceProfile):
        profiles = [profiles]
    
    summary = {
        'count': len(profiles),
        'profiles': []
    }
    
    for profile in profiles:
        summary['profiles'].append({
            'name': profile.name,
            'gender': profile.gender,
            'age_group': profile.age_group,
            'mean_pitch': profile.mean_pitch,
            'confidence': profile.confidence
        })
    
    # Determine dominant gender
    genders = [p.gender for p in profiles]
    summary['dominant_gender'] = max(set(genders), key=genders.count) if genders else 'unknown'
    
    return summary
