#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
os.environ['FLASK_ENV'] = 'development'

from app import app

# Test with Flask test client
client = app.test_client()

# Test main page
response = client.get('/')
print('GET / status:', response.status_code)

if response.status_code == 200:
    data = response.data
    if b'DubbingAI' in data:
        print('SUCCESS: DubbingAI found in page!')
    else:
        print('Page loaded but DubbingAI not found')
        print('First 500 chars:', data[:500])
else:
    print('ERROR:', response.data)
