# DubbingAI Pro - Professional Brazilian Portuguese Dubbing App

## 1. Project Overview

**Project Name:** DubbingAI Pro  
**Type:** Web Application (Python/Flask + HTML/CSS/JS)  
**Core Functionality:** A professional web application that translates audio/video to Brazilian Portuguese with advanced emotion preservation, voice cloning, and professional dubbing quality matching Brazilian studio standards.

**Target Users:** 
- Content creators
- Filmmakers and video producers
- Anime and movie fans
- YouTubers and streamers
- Anyone needing professional Brazilian Portuguese dubbing

---

## 2. Technical Architecture

### Backend (Python)
- **Framework:** Flask 2.3+
- **Speech Recognition:** OpenAI Whisper (latest version)
- **Translation:** Deep Translator / Google Translator
- **Emotion Analysis:** Custom audio analysis with librosa
- **Voice Cloning:** Pitch shifting and voice characteristic matching
- **TTS Engines:**
  - Edge TTS (primary - best PT-BR quality)
  - Coqui TTS (optional - for voice cloning)
  - Bark (optional - for emotional TTS)
  - pyttsx3 (fallback)

### Frontend (HTML/CSS/JS)
- **Design:** Modern dark theme with purple accents
- **Features:** 
  - Drag-and-drop upload
  - Real-time analysis display
  - Voice preset selection
  - Emotion preservation toggle
  - Voice cloning toggle
  - Progress visualization

---

## 3. Core Features

### 3.1 Emotion Analysis
- **Pitch Contour Analysis:** Analyzes F0 variations to detect emotional state
- **Energy Pattern Detection:** Identifies intensity changes
- **Speaking Rate Analysis:** Measures WPM for emotion detection
- **Emotion Categories:**
  - Neutral, Happy, Sad, Angry, Fearful, Surprised
  - Disgusted, Excited, Calm, Romantic, Dramatic, Comedic

### 3.2 Voice Cloning
- **Voice Profile Extraction:**
  - Fundamental frequency (F0) extraction
  - MFCC spectral features
  - Formant frequencies
  - Timbre signature (centroid, bandwidth, rolloff)
- **Voice Conversion:**
  - Pitch shifting to match source
  - Speed adjustment
  - Energy modulation

### 3.3 Brazilian Portuguese Dubbing Styles
- **Preset Categories:**
  - Character Voices (Young, Adult, Elder - Male/Female)
  - Neutral/Narration (Male/Female)
  - Dubbing Styles:
    - Anime (Male/Female)
    - Cartoon
    - Movie Drama
    - Movie Action
    - Documentary
    - Comedy
    - Romance
    - Horror

### 3.4 Text Adaptation
- Slang translations (American English → Brazilian Portuguese)
- Cultural adaptations
- Emotional expression mapping

---

## 4. User Flow

1. User uploads video/audio file
2. System analyzes audio:
   - Detects emotions
   - Extracts voice characteristics
   - Identifies gender
3. System displays analysis results
4. User configures:
   - Content type
   - Voice preset (or auto)
   - Emotion preservation (on/off)
   - Voice cloning (on/off)
5. User clicks "Start Dubbing"
6. System processes:
   - Transcribes audio
   - Translates to PT-BR
   - Generates dubbed audio
   - Merges with video
7. User previews and downloads result

---

## 5. API Endpoints

### Upload
- `POST /api/upload` - Upload video/audio file

### Analysis
- `POST /api/analyze` - Analyze audio for emotions and voice

### Processing
- `POST /api/process` - Generate professional dubbing

### Information
- `GET /api/presets` - Get available voice presets
- `GET /api/emotions` - Get available emotion settings
- `GET /api/voice-profiles/<session_id>` - Get saved voice profile

### Utilities
- `GET /api/status/<session_id>` - Check processing status
- `GET /api/download/<filename>` - Download processed video
- `POST /api/cleanup` - Clean up old files

---

## 6. File Structure

```
VideoTranslatorApp/
├── app.py                      # Main Flask application
├── requirements.txt            # Python dependencies
├── SPEC.md                    # This specification
├── static/
│   ├── css/
│   │   └── style.css          # Main styling
│   ├── js/
│   │   └── app.js             # Frontend logic
│   ├── uploads/               # Temporary upload storage
│   ├── output/                # Processed videos
│   └── voice_profiles/        # Saved voice profiles
├── templates/
│   └── index.html             # Main page
└── processors/
    ├── __init__.py
    ├── audio_processor.py     # Audio extraction
    ├── voice_detector.py      # Gender detection
    ├── transcriber.py         # Whisper transcription
    ├── translator.py          # Translation
    ├── tts_generator.py       # Basic TTS
    ├── video_merger.py        # Video+audio merge
    ├── emotion_analyzer.py    # Emotion analysis
    ├── ptbr_dubbing_style.py # Brazilian dubbing styles
    ├── voice_cloner.py        # Voice cloning
    └── pro_tts_generator.py  # Professional TTS
```

---

## 7. New Modules

### emotion_analyzer.py
Analyzes emotional content from audio including tone, pitch variations, and speech patterns to preserve emotions during dubbing.

### ptbr_dubbing_style.py
Handles voice presets, dubbing styles, and Brazilian-specific dubbing characteristics.

### voice_cloner.py
Creates voice profiles from source audio to preserve original voice characteristics.

### pro_tts_generator.py
Advanced TTS generation with emotion preservation and voice cloning support.

---

## 8. Acceptance Criteria

- [x] User can upload video/audio files via drag-drop
- [x] App analyzes and displays emotions detected
- [x] App extracts and displays voice characteristics
- [x] User can select voice preset
- [x] User can toggle emotion preservation
- [x] User can toggle voice cloning
- [x] Transcription is accurate and timestamped
- [x] Translation to Brazilian Portuguese is fluent
- [x] Dubbed voice matches original gender
- [x] Sound effects are preserved in final video
- [x] Downloadable MP4 with dubbed audio
- [x] Progress indicators for all processing steps
- [x] Modern responsive design

---

## 9. Dependencies

```
# Core Flask
flask>=2.3.0
flask-cors>=4.0.0
werkzeug>=2.3.0

# Audio Processing
librosa>=0.10.0
soundfile>=0.12.1
pydub>=0.25.1
numpy>=1.24.0
scipy>=1.10.0

# Video Processing
moviepy>=1.0.3

# AI/ML
torch>=2.0.0
transformers>=4.30.0

# Speech Recognition
openai-whisper>=20231117

# Translation
deep-translator>=1.11.0

# TTS - Professional
edge-tts>=6.1.0

# pyttsx3 (fallback TTS)
pyttsx3>=2.90
```

---

## 10. Notes

- Edge TTS provides the best Brazilian Portuguese voice quality
- First run will download Whisper model (~140MB for base)
- Processing time depends on video length and hardware
- For production, consider using GPU acceleration
- Voice cloning is simplified - full cloning requires additional models
