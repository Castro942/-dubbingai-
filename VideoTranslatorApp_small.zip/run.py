# -*- coding: utf-8 -*-
"""Simple test to check Flask app"""
import sys
sys.path.insert(0, '.')

print("Testing Flask app import...")
from app import app
print("Flask app imported successfully!")
print(f"Routes: {len(app.url_map._rules)} routes available")
print("App is ready to run!")
