"""
Emotion Analyzer Module
Analyzes emotional content from audio including tone, pitch variations, and speech patterns
to preserve emotions during dubbing
"""

import os
import logging
import numpy as np
from pydub import AudioSegment
import json

# Try to import required libraries
try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False
    print("WARNING: librosa not available. Emotion analysis will use basic methods.")

try:
    import soundfile as sf
    SOUNDFILE_AVAILABLE = True
except ImportError:
    SOUNDFILE_AVAILABLE = False

logger = logging.getLogger(__name__)

# Emotion categories for Brazilian Portuguese dubbing
EMOTION_CATEGORIES = {
    'neutral': {'intensity': 0.5, 'pitch_modifier': 1.0, 'rate_modifier': 1.0},
    'happy': {'intensity': 0.8, 'pitch_modifier': 1.1, 'rate_modifier': 1.15},
    'sad': {'intensity': 0.4, 'pitch_modifier': 0.95, 'rate_modifier': 0.85},
    'angry': {'intensity': 0.9, 'pitch_modifier': 1.15, 'rate_modifier': 1.2},
    'fearful': {'intensity': 0.7, 'pitch_modifier': 1.2, 'rate_modifier': 1.3},
    'surprised': {'intensity': 0.8, 'pitch_modifier': 1.25, 'rate_modifier': 1.1},
    'disgusted': {'intensity': 0.6, 'pitch_modifier': 0.9, 'rate_modifier': 0.95},
    'excited': {'intensity': 0.9, 'pitch_modifier': 1.15, 'rate_modifier': 1.25},
    'calm': {'intensity': 0.4, 'pitch_modifier': 0.98, 'rate_modifier': 0.9},
    'romantic': {'intensity': 0.6, 'pitch_modifier': 1.05, 'rate_modifier': 0.95},
    'dramatic': {'intensity': 0.8, 'pitch_modifier': 1.1, 'rate_modifier': 0.9},
    'comedic': {'intensity': 0.7, 'pitch_modifier': 1.08, 'rate_modifier': 1.2}
}

def analyze_pitch_contour(audio_path, segment_duration=3.0):
    """
    Analyze pitch contour to detect emotional variations
    
    Args:
        audio_path: Path to audio file
        segment_duration: Duration of segments to analyze
        
    Returns:
        List of pitch data with timestamps
    """
    if not LIBROSA_AVAILABLE:
        return basic_pitch_analysis(audio_path)
    
    try:
        logger.info(f"Analyzing pitch contour: {audio_path}")
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050)
        duration = len(y) / sr
        
        hop_length = 512
        frame_length = 2048
        
        segments = []
        segment_samples = int(segment_duration * sr)
        num_segments = int(duration / segment_duration)
        
        for i in range(num_segments):
            start_sample = i * segment_samples
            end_sample = min((i + 1) * segment_samples, len(y))
            
            if end_sample - start_sample < segment_samples * 0.5:
                continue
            
            y_segment = y[start_sample:end_sample]
            
            # Extract pitch using pyin
            try:
                f0, voiced_flag, voiced_probs = librosa.pyin(
                    y_segment,
                    fmin=50,
                    fmax=500,
                    sr=sr,
                    hop_length=hop_length
                )
                
                # Get statistics
                f0_valid = f0[~np.isnan(f0)]
                
                if len(f0_valid) > 0:
                    segments.append({
                        'start_time': i * segment_duration,
                        'end_time': (i + 1) * segment_duration,
                        'mean_pitch': float(np.mean(f0_valid)),
                        'median_pitch': float(np.median(f0_valid)),
                        'std_pitch': float(np.std(f0_valid)),
                        'min_pitch': float(np.min(f0_valid)),
                        'max_pitch': float(np.max(f0_valid)),
                        'pitch_range': float(np.max(f0_valid) - np.min(f0_valid)),
                        'voiced_ratio': len(f0_valid) / len(f0) if len(f0) > 0 else 0
                    })
            except Exception as e:
                logger.warning(f"Pitch analysis failed for segment {i}: {str(e)}")
                continue
        
        logger.info(f"Pitch analysis complete: {len(segments)} segments")
        return segments
        
    except Exception as e:
        logger.error(f"Pitch contour analysis error: {str(e)}")
        return []

def analyze_energy_contour(audio_path, segment_duration=0.5):
    """
    Analyze energy/volume contour to detect emotional intensity
    
    Args:
        audio_path: Path to audio file
        segment_duration: Duration of segments
        
    Returns:
        List of energy data with timestamps
    """
    if not LIBROSA_AVAILABLE:
        return []
    
    try:
        logger.info("Analyzing energy contour")
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=22050)
        duration = len(y) / sr
        
        # Calculate RMS energy
        hop_length = 512
        frame_length = 2048
        
        # Get RMS energy per frame
        rms = librosa.feature.rms(
            y=y,
            frame_length=frame_length,
            hop_length=hop_length
        )[0]
        
        # Convert to segments
        samples_per_frame = hop_length
        samples_per_segment = int(segment_duration * sr)
        frames_per_segment = samples_per_segment // hop_length
        
        segments = []
        num_segments = int(duration / segment_duration)
        
        for i in range(num_segments):
            start_frame = i * frames_per_segment
            end_frame = min((i + 1) * frames_per_segment, len(rms))
            
            if end_frame - start_frame < 1:
                continue
            
            segment_rms = rms[start_frame:end_frame]
            
            segments.append({
                'start_time': i * segment_duration,
                'end_time': (i + 1) * segment_duration,
                'mean_energy': float(np.mean(segment_rms)),
                'max_energy': float(np.max(segment_rms)),
                'std_energy': float(np.std(segment_rms)),
                'energy_range': float(np.max(segment_rms) - np.min(segment_rms))
            })
        
        return segments
        
    except Exception as e:
        logger.error(f"Energy analysis error: {str(e)}")
        return []

def analyze_speaking_rate(audio_path):
    """
    Analyze speaking rate (words per minute estimation)
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Speaking rate data
    """
    try:
        # This would ideally use transcription to count words
        # For now, use syllable estimation based on energy peaks
        
        if not LIBROSA_AVAILABLE:
            return {'estimated_wpm': 150, 'syllable_rate': 4.5}
        
        y, sr = librosa.load(audio_path, sr=22050)
        
        # Detect onset strength
        onset_env = librosa.onset.onset_strength(y=y, sr=sr)
        
        # Estimate syllables from onset peaks
        onset_peaks = librosa.util.peak_pick(onset_env, 3, 3, 3, 5, 0.5)
        
        duration = len(y) / sr
        syllable_rate = len(onset_peaks) / duration
        
        # Estimate WPM (average syllables / word ≈ 1.5)
        estimated_wpm = (syllable_rate / 1.5) * 60
        
        return {
            'estimated_wpm': float(estimated_wpm),
            'syllable_rate': float(syllable_rate),
            'num_syllables': len(onset_peaks),
            'duration': float(duration)
        }
        
    except Exception as e:
        logger.error(f"Speaking rate analysis error: {str(e)}")
        return {'estimated_wpm': 150, 'syllable_rate': 4.5}

def basic_pitch_analysis(audio_path):
    """
    Basic pitch analysis without librosa
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Basic pitch data
    """
    try:
        audio = AudioSegment.from_wav(audio_path)
        duration = len(audio) / 1000.0
        
        # Simple energy-based segmentation
        samples = np.array(audio.get_array_of_samples())
        sample_rate = audio.frame_rate
        
        # Divide into segments
        segment_duration = 3.0
        num_segments = int(duration / segment_duration)
        
        segments = []
        samples_per_segment = int(sample_rate * segment_duration)
        
        for i in range(num_segments):
            start = i * samples_per_segment
            end = min((i + 1) * samples_per_segment, len(samples))
            
            if end - start < samples_per_segment * 0.5:
                continue
            
            segment = samples[start:end]
            
            # Basic frequency estimation using zero crossings
            zero_crossings = np.sum(np.diff(np.sign(segment)) != 0)
            estimated_freq = zero_crossings * sample_rate / (2 * len(segment))
            
            # Only accept reasonable voice frequencies
            if 50 < estimated_freq < 500:
                segments.append({
                    'start_time': i * segment_duration,
                    'end_time': (i + 1) * segment_duration,
                    'mean_pitch': estimated_freq,
                    'median_pitch': estimated_freq,
                    'std_pitch': 0,
                    'voiced_ratio': 0.5
                })
        
        return segments
        
    except Exception as e:
        logger.error(f"Basic pitch analysis error: {str(e)}")
        return []

def detect_emotion(pitch_data, energy_data, speaking_rate_data):
    """
    Detect emotion based on audio features
    
    Args:
        pitch_data: List of pitch segments
        energy_data: List of energy segments
        speaking_rate_data: Speaking rate info
        
    Returns:
        Detected emotion and confidence
    """
    if not pitch_data or len(pitch_data) == 0:
        return 'neutral', 0.5
    
    try:
        # Aggregate pitch statistics
        mean_pitch = np.mean([s['mean_pitch'] for s in pitch_data])
        pitch_variability = np.std([s['mean_pitch'] for s in pitch_data]) / mean_pitch if mean_pitch > 0 else 0
        
        # Get energy statistics
        if energy_data:
            mean_energy = np.mean([s['mean_energy'] for s in energy_data])
            energy_variability = np.std([s['mean_energy'] for s in energy_data]) if energy_data else 0
        else:
            mean_energy = 0.5
            energy_variability = 0.1
        
        # Speaking rate
        wpm = speaking_rate_data.get('estimated_wpm', 150)
        
        # Emotion detection logic based on acoustic features
        # High pitch + high energy + fast speech = excited/happy
        # Low pitch + low energy + slow speech = sad/calm
        # High pitch variability + irregular energy = fearful/surprised
        # High energy + medium-high pitch + fast speech = angry
        
        emotion_scores = {}
        
        # Neutral
        emotion_scores['neutral'] = 0.5 - abs(pitch_variability - 0.1) - abs(energy_variability - 0.1)
        
        # Happy/Excited
        emotion_scores['happy'] = (
            (pitch_variability * 2) + 
            (energy_variability * 1.5) + 
            (wpm / 300) +
            ((mean_pitch - 150) / 100)
        )
        
        # Sad
        emotion_scores['sad'] = (
            (1 - pitch_variability * 3) + 
            (1 - energy_variability * 2) + 
            (1 - wpm / 200) +
            ((150 - mean_pitch) / 100)
        )
        
        # Angry
        emotion_scores['angry'] = (
            energy_variability * 3 + 
            pitch_variability * 2 +
            (wpm / 250) +
            ((mean_pitch - 130) / 80)
        )
        
        # Fearful
        emotion_scores['fearful'] = (
            pitch_variability * 3 +
            energy_variability * 2 +
            ((mean_pitch - 180) / 60)
        )
        
        # Surprised
        emotion_scores['surprised'] = (
            pitch_variability * 2.5 +
            energy_variability * 2 +
            ((mean_pitch - 170) / 70)
        )
        
        # Calm
        emotion_scores['calm'] = (
            (1 - pitch_variability * 4) +
            (1 - energy_variability * 3) +
            (1 - wpm / 200)
        )
        
        # Dramatic (common in Brazilian dubbing)
        emotion_scores['dramatic'] = (
            pitch_variability * 2 +
            energy_variability * 1.5 +
            abs((wpm - 140) / 50)
        )
        
        # Comedic
        emotion_scores['comedic'] = (
            pitch_variability * 2.5 +
            energy_variability * 1.8 +
            (wpm / 200)
        )
        
        # Romantic (soft, slower, moderate pitch)
        emotion_scores['romantic'] = (
            (1 - pitch_variability * 2) +
            (1 - energy_variability * 2) +
            (1 - wpm / 180)
        )
        
        # Find best match
        best_emotion = max(emotion_scores, key=emotion_scores.get)
        confidence = min(1.0, max(0.3, emotion_scores[best_emotion] / 3))
        
        # Cap confidence
        confidence = max(0.3, min(0.95, confidence))
        
        logger.info(f"Detected emotion: {best_emotion} (confidence: {confidence:.2f})")
        
        return best_emotion, confidence
        
    except Exception as e:
        logger.error(f"Emotion detection error: {str(e)}")
        return 'neutral', 0.5

def analyze_emotions(audio_path):
    """
    Comprehensive emotion analysis of audio
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Dictionary with emotion analysis results
    """
    try:
        logger.info(f"Starting emotion analysis: {audio_path}")
        
        # Analyze pitch
        pitch_data = analyze_pitch_contour(audio_path)
        
        # Analyze energy
        energy_data = analyze_energy_contour(audio_path)
        
        # Analyze speaking rate
        speaking_rate_data = analyze_speaking_rate(audio_path)
        
        # Detect primary emotion
        primary_emotion, confidence = detect_emotion(pitch_data, energy_data, speaking_rate_data)
        
        # Get emotion parameters for TTS
        emotion_params = EMOTION_CATEGORIES.get(primary_emotion, EMOTION_CATEGORIES['neutral'])
        
        # Analyze each segment for emotion variations
        segment_emotions = []
        if pitch_data and energy_data:
            # Match segments
            min_len = min(len(pitch_data), len(energy_data))
            for i in range(min_len):
                seg_pitch = pitch_data[i]
                seg_energy = energy_data[i * len(energy_data) // min_len] if len(energy_data) > 0 else energy_data[0]
                
                # Simple emotion detection per segment
                segment_emotion, seg_conf = detect_emotion(
                    [seg_pitch], 
                    [seg_energy], 
                    speaking_rate_data
                )
                segment_emotions.append({
                    'start_time': seg_pitch['start_time'],
                    'end_time': seg_pitch['end_time'],
                    'emotion': segment_emotion,
                    'confidence': seg_conf
                })
        
        result = {
            'primary_emotion': primary_emotion,
            'confidence': confidence,
            'emotion_params': emotion_params,
            'pitch_data': pitch_data[:20] if pitch_data else [],  # Limit for storage
            'speaking_rate': speaking_rate_data,
            'segment_emotions': segment_emotions[:50] if segment_emotions else [],
            'available': True
        }
        
        logger.info(f"Emotion analysis complete: {primary_emotion} ({confidence:.2f})")
        
        return result
        
    except Exception as e:
        logger.error(f"Emotion analysis error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Return default
        return {
            'primary_emotion': 'neutral',
            'confidence': 0.5,
            'emotion_params': EMOTION_CATEGORIES['neutral'],
            'pitch_data': [],
            'speaking_rate': {'estimated_wpm': 150},
            'segment_emotions': [],
            'available': False
        }

def get_emotion_for_tts(emotion_data):
    """
    Extract emotion parameters for TTS generation
    
    Args:
        emotion_data: Emotion analysis result
        
    Returns:
        Dictionary with TTS emotion parameters
    """
    if not emotion_data or not emotion_data.get('available'):
        return {
            'emotion': 'neutral',
            'intensity': 0.5,
            'pitch_modifier': 1.0,
            'rate_modifier': 1.0
        }
    
    emotion = emotion_data.get('primary_emotion', 'neutral')
    params = emotion_data.get('emotion_params', EMOTION_CATEGORIES['neutral'])
    
    return {
        'emotion': emotion,
        'intensity': params.get('intensity', 0.5),
        'pitch_modifier': params.get('pitch_modifier', 1.0),
        'rate_modifier': params.get('rate_modifier', 1.0),
        'confidence': emotion_data.get('confidence', 0.5)
    }

def map_emotion_to_ptbr_style(emotion):
    """
    Map detected emotion to Brazilian Portuguese dubbing style
    
    Args:
        emotion: Detected emotion
        
    Returns:
        PTBR dubbing style recommendation
    """
    style_mapping = {
        'neutral': {
            'voice_type': 'neutro',
            'intonation': 'natural',
            'pace': 'normal',
            'recommended_voice_preset': 'default'
        },
        'happy': {
            'voice_type': 'alegre',
            'intonation': 'subida',
            'pace': 'moderado',
            'recommended_voice_preset': 'happy'
        },
        'sad': {
            'voice_type': 'triste',
            'intonation': 'desce',
            'pace': 'lento',
            'recommended_voice_preset': 'sad'
        },
        'angry': {
            'voice_type': 'irritado',
            'intonation': 'forte',
            'pace': 'rapido',
            'recommended_voice_preset': 'angry'
        },
        'fearful': {
            'voice_type': 'amedrontado',
            'intonation': 'oscilante',
            'pace': 'rapido',
            'recommended_voice_preset': 'fearful'
        },
        'surprised': {
            'voice_type': 'surpreso',
            'intonation': 'subida',
            'pace': 'rapido',
            'recommended_voice_preset': 'surprised'
        },
        'disgusted': {
            'voice_type': 'nojo',
            'intonation': 'desce',
            'pace': 'lento',
            'recommended_voice_preset': 'disgusted'
        },
        'excited': {
            'voice_type': 'animado',
            'intonation': 'alta',
            'pace': 'rapido',
            'recommended_voice_preset': 'excited'
        },
        'calm': {
            'voice_type': 'calmo',
            'intonation': 'natural',
            'pace': 'lento',
            'recommended_voice_preset': 'calm'
        },
        'romantic': {
            'voice_type': 'romantico',
            'intonation': 'suave',
            'pace': 'lento',
            'recommended_voice_preset': 'romantic'
        },
        'dramatic': {
            'voice_type': 'dramatico',
            'intonation': 'enfatica',
            'pace': 'pausado',
            'recommended_voice_preset': 'dramatic'
        },
        'comedic': {
            'voice_type': 'comico',
            'intonation': 'variada',
            'pace': 'moderado',
            'recommended_voice_preset': 'comedic'
        }
    }
    
    return style_mapping.get(emotion, style_mapping['neutral'])
