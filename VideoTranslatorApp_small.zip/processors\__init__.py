"""
Video Translator Processors
Contains all the processing modules for video translation
"""

from .audio_processor import extract_audio
from .voice_detector import detect_voice_genders
from .transcriber import transcribe_audio
from .translator import translate_text
from .tts_generator import generate_dubbed_audio
from .video_merger import merge_audio_video

__all__ = [
    'extract_audio',
    'detect_voice_genders', 
    'transcribe_audio',
    'translate_text',
    'generate_dubbed_audio',
    'merge_audio_video'
]
